package pl.aimasterpro.app.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import pl.aimasterpro.app.core.CompanionIdentityChallenge
import pl.aimasterpro.app.core.CompanionPeerPinSet
import pl.aimasterpro.app.core.CompanionPinnedTlsProfile
import pl.aimasterpro.app.core.CompanionPairingAuthority
import pl.aimasterpro.app.core.CompanionSessionOwner
import pl.aimasterpro.app.core.CompanionSpkiSha256Pin
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.Signature
import java.security.cert.X509Certificate
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Raised when persisted Companion trust data cannot be decrypted; recovery must be explicit. */
class CompanionProvisioningRecoveryRequiredException(message: String, cause: Throwable? = null) :
    IllegalStateException(message, cause)

/** Public, non-secret description of the local Keystore identity. */
data class CompanionLocalIdentity(
    val alias: String,
    val certificate: X509Certificate,
    val publicKeySha256: String
)

/**
 * Android-backed Companion provisioning primitives.
 * Private signing and metadata-encryption keys never leave Android Keystore. Peer pins are stored
 * as authenticated ciphertext in app-private preferences. Loss of the metadata key is fail-closed:
 * this class never silently creates a replacement that would make old trust records disappear.
 * The generated Keystore certificate is a local key identity, not a CA-issued TLS certificate;
 * production TLS still requires a certificate chain with the correct SANs from the pairing/CA flow.
 */
class CompanionProvisioningStore(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    @Synchronized
    fun provisionLocalIdentity(): CompanionLocalIdentity {
        val store = androidKeyStore()
        if (!store.containsAlias(IDENTITY_ALIAS)) {
            val generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, ANDROID_KEY_STORE)
            generator.initialize(
                KeyGenParameterSpec.Builder(
                    IDENTITY_ALIAS,
                    KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
                )
                    .setAlgorithmParameterSpec(java.security.spec.ECGenParameterSpec("secp256r1"))
                    .setDigests(KeyProperties.DIGEST_SHA256)
                    .setCertificateSubject(javax.security.auth.x500.X500Principal("CN=AI MASTER Companion"))
                    .setCertificateSerialNumber(java.math.BigInteger.valueOf(1L))
                    .setCertificateNotBefore(java.util.Date(0L))
                    .setCertificateNotAfter(java.util.Date(4_102_444_800_000L))
                    .build()
            )
            generator.generateKeyPair()
        }
        val certificate = store.getCertificate(IDENTITY_ALIAS) as? X509Certificate
            ?: throw CompanionProvisioningRecoveryRequiredException("Brak certyfikatu lokalnej tożsamości Companion.")
        val privateKey = store.getKey(IDENTITY_ALIAS, null) as? java.security.PrivateKey
            ?: throw CompanionProvisioningRecoveryRequiredException("Brak prywatnego klucza lokalnej tożsamości Companion.")
        require(privateKey.algorithm.equals("EC", ignoreCase = true)) {
            "Nieobsługiwany algorytm klucza lokalnej tożsamości Companion."
        }
        val digest = java.security.MessageDigest.getInstance("SHA-256").digest(certificate.publicKey.encoded)
        val fingerprint = digest.joinToString("") { "%02x".format(java.util.Locale.ROOT, it) }
        return CompanionLocalIdentity(IDENTITY_ALIAS, certificate, fingerprint)
    }

    /** Signs a challenge with the non-exportable local EC private key. */
    @Synchronized
    fun signChallenge(challenge: ByteArray): ByteArray {
        val signedMessage = CompanionIdentityChallenge.message(challenge)
        val store = androidKeyStore()
        val key = store.getKey(IDENTITY_ALIAS, null) as? java.security.PrivateKey
            ?: throw IllegalStateException("Lokalna tożsamość Companion nie została provisionowana.")
        return Signature.getInstance("SHA256withECDSA").run {
            initSign(key)
            update(signedMessage)
            sign()
        }
    }

    @Synchronized
    fun readPeerPins(): Map<String, CompanionPeerPinSet> = decodeRecords(readEncryptedPayload())

    /** Ready-to-use peerId -> accepted current/next SPKI map for CompanionPinnedTlsProfile.create(). */
    @Synchronized
    fun readTlsPinsByPeerId(): Map<String, Set<CompanionSpkiSha256Pin>> =
        readPeerPins().mapValues { (_, pins) -> setOfNotNull(pins.current, pins.next) }

    /**
     * Builds a fresh TLS profile from the currently persisted trust snapshot. The identity
     * KeyStore must contain a TLS-capable private key and its complete certificate chain; the
     * locally generated self-signed provisioning certificate is not automatically suitable for
     * TLS because it has no issued SAN/CA chain. Call this again after trust changes and close
     * all sessions/profiles created from an older snapshot after peer revocation.
     */
    @Synchronized
    fun createPinnedTlsProfile(
        tlsIdentityKeyStore: KeyStore,
        keyPassword: CharArray?,
        trustStore: KeyStore
    ): CompanionPinnedTlsProfile {
        val pins = readTlsPinsByPeerId()
        check(pins.isNotEmpty()) { "Brak provisionowanych peerów; TLS Companion pozostaje zablokowany." }
        return CompanionPinnedTlsProfile.create(tlsIdentityKeyStore, keyPassword, trustStore, pins)
    }

    /**
     * Preferred construction path: snapshots the persisted peer pins into a private TLS profile
     * and binds that exact profile to the new session owner. The owner also revalidates its
     * authenticated peer against the encrypted current/next pin record before each session
     * operation; rotation promotion or revocation therefore fails the session closed on its next
     * operation, even when its TLS profile was created from an older snapshot.
     */
    @Synchronized
    fun createSessionOwner(
        pairingAuthority: CompanionPairingAuthority,
        pairingSecret: ByteArray,
        tlsIdentityKeyStore: KeyStore,
        keyPassword: CharArray?,
        trustStore: KeyStore,
        handshakeTimeoutNanos: Long,
        idleTimeoutNanos: Long,
        transferTimeoutNanos: Long,
        hardLifetimeNanos: Long
    ): CompanionSessionOwner {
        val profile = createPinnedTlsProfile(tlsIdentityKeyStore, keyPassword, trustStore)
        return CompanionSessionOwner(
            pairingAuthority,
            pairingSecret,
            profile,
            handshakeTimeoutNanos,
            idleTimeoutNanos,
            transferTimeoutNanos,
            hardLifetimeNanos,
            trustValidator = { peerId, pin ->
                try {
                    synchronized(this) {
                        readPeerPins()[peerId]?.accepts(pin) == true
                    }
                } catch (_: Exception) {
                    false
                }
            }
        )
    }

    @Synchronized
    fun cancelPeerRotation(peerId: String) {
        validatePeerId(peerId)
        val records = decodeRecords(readEncryptedPayload()).toMutableMap()
        val existing = records[peerId] ?: throw IllegalArgumentException("Nieznany peer.")
        records[peerId] = existing.cancelStaged()
        persist(records)
    }

    @Synchronized
    fun provisionPeer(peerId: String, currentPin: CompanionSpkiSha256Pin) {
        validatePeerId(peerId)
        val records = decodeRecords(readEncryptedPayload()).toMutableMap()
        require(peerId !in records) { "Peer jest już provisionowany; użyj jawnej procedury rotacji." }
        records[peerId] = CompanionPeerPinSet(currentPin)
        persist(records)
    }

    @Synchronized
    fun stagePeerRotation(peerId: String, nextPin: CompanionSpkiSha256Pin) {
        validatePeerId(peerId)
        val records = decodeRecords(readEncryptedPayload()).toMutableMap()
        val existing = records[peerId] ?: throw IllegalArgumentException("Nieznany peer.")
        records[peerId] = existing.stage(nextPin)
        persist(records)
    }

    @Synchronized
    fun promotePeerRotation(peerId: String) {
        validatePeerId(peerId)
        val records = decodeRecords(readEncryptedPayload()).toMutableMap()
        val existing = records[peerId] ?: throw IllegalArgumentException("Nieznany peer.")
        records[peerId] = existing.promoteNext()
        persist(records)
    }

    /** Revocation removes both current and staged pins; the peer must be paired again to return. */
    @Synchronized
    fun revokePeer(peerId: String) {
        validatePeerId(peerId)
        val records = decodeRecords(readEncryptedPayload()).toMutableMap()
        if (records.remove(peerId) != null) persist(records)
    }

    private fun persist(records: Map<String, CompanionPeerPinSet>) {
        require(records.size <= MAX_PEERS) { "Osiągnięto limit provisionowanych peerów." }
        val json = JSONObject()
        records.toSortedMap().forEach { (id, pins) ->
            json.put(id, JSONObject().put("current", pins.current.toString()).apply {
                pins.next?.let { put("next", it.toString()) }
            })
        }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, metadataKey())
        cipher.updateAAD(AAD.toByteArray(Charsets.UTF_8))
        val encrypted = cipher.doFinal(json.toString().toByteArray(Charsets.UTF_8))
        val packed = cipher.iv + encrypted
        val saved = prefs.edit().putString(PINS_KEY, Base64.encodeToString(packed, Base64.NO_WRAP)).commit()
        check(saved) { "Nie udało się trwale zapisać mapy zaufania Companion." }
    }

    private fun readEncryptedPayload(): String {
        val encoded = prefs.getString(PINS_KEY, null) ?: return "{}"
        try {
            val packed = Base64.decode(encoded, Base64.NO_WRAP)
            require(packed.size in (GCM_IV_BYTES + GCM_TAG_BYTES)..MAX_ENCRYPTED_BYTES) { "Nieprawidłowy rozmiar magazynu Companion." }
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, metadataKey(), GCMParameterSpec(GCM_TAG_BITS, packed.copyOfRange(0, GCM_IV_BYTES)))
            cipher.updateAAD(AAD.toByteArray(Charsets.UTF_8))
            return String(cipher.doFinal(packed.copyOfRange(GCM_IV_BYTES, packed.size)), Charsets.UTF_8)
        } catch (error: Exception) {
            throw CompanionProvisioningRecoveryRequiredException(
                "Nie można uwierzytelnić magazynu zaufania Companion. Dane pozostają zablokowane; wymagane jawne ponowne parowanie.", error
            )
        }
    }

    private fun decodeRecords(payload: String): Map<String, CompanionPeerPinSet> {
        val root = JSONObject(payload)
        require(root.length() <= MAX_PEERS) { "Magazyn zawiera zbyt wiele peerów." }
        val result = linkedMapOf<String, CompanionPeerPinSet>()
        val keys = root.keys()
        while (keys.hasNext()) {
            val id = keys.next()
            validatePeerId(id)
            val item = root.getJSONObject(id)
            val current = CompanionSpkiSha256Pin.parse(item.getString("current"))
            val next = if (item.has("next")) CompanionSpkiSha256Pin.parse(item.getString("next")) else null
            result[id] = CompanionPeerPinSet(current, next)
        }
        return result.toMap()
    }

    private fun metadataKey(): SecretKey {
        val store = androidKeyStore()
        if (store.containsAlias(METADATA_ALIAS)) {
            return store.getKey(METADATA_ALIAS, null) as? SecretKey
                ?: throw CompanionProvisioningRecoveryRequiredException("Klucz szyfrujący magazyn Companion ma nieprawidłowy typ.")
        }
        if (prefs.contains(PINS_KEY)) {
            throw CompanionProvisioningRecoveryRequiredException("Brak klucza Android Keystore do istniejących danych Companion.")
        }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEY_STORE)
        generator.init(
            KeyGenParameterSpec.Builder(METADATA_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun androidKeyStore(): KeyStore = KeyStore.getInstance(ANDROID_KEY_STORE).apply { load(null) }

    private fun validatePeerId(peerId: String) {
        require(peerId.matches(Regex("[A-Za-z0-9._-]{1,80}"))) { "Nieprawidłowy identyfikator peer." }
    }

    companion object {
        private const val ANDROID_KEY_STORE = "AndroidKeyStore"
        private const val PREFS_NAME = "companion_provisioning_v1"
        private const val IDENTITY_ALIAS = "ai_master_companion_identity_v1"
        private const val METADATA_ALIAS = "ai_master_companion_metadata_aes_v1"
        private const val PINS_KEY = "peer_pin_records_v1"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val AAD = "AI_MASTER_COMPANION_PEER_PINS_V1"
        private const val GCM_IV_BYTES = 12
        private const val GCM_TAG_BITS = 128
        private const val GCM_TAG_BYTES = 16
        private const val MAX_PEERS = 64
        private const val MAX_ENCRYPTED_BYTES = 64 * 1024
    }
}
