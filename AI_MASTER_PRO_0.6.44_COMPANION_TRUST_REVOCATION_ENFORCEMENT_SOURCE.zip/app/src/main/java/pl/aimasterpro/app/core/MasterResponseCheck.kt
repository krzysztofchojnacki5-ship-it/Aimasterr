package pl.aimasterpro.app.core

import java.util.Locale

/** Cheap structural checks only; flags uncertainty instead of silently rewriting factual content. */
object MasterResponseCheck {
    data class Result(val passed: Boolean, val warnings: List<String>)
    fun evaluate(prompt: String, answer: String): Result {
        val q = prompt.lowercase(Locale.ROOT)
        val a = answer.trim()
        val warnings = mutableListOf<String>()
        if (a.isBlank()) warnings += "Odpowiedź jest pusta."
        if (a.length < 40 && q.length > 100) warnings += "Odpowiedź może być zbyt krótka względem złożoności pytania."
        val asksForSteps = listOf("krok po kroku", "instrukcj", "jak zrobić", "jak zrobic", "wdroż", "wdroz").any(q::contains)
        if (asksForSteps && !listOf("1.", "1)", "krok", "najpierw", "następnie", "nastepnie").any(a.lowercase(Locale.ROOT)::contains)) warnings += "Użytkownik prosi o instrukcję, ale odpowiedź nie ma wyraźnej sekwencji kroków."
        val asksForComparison = listOf("porównaj", "porownaj", "różnic", "roznic", "lepszy", "najlepszy").any(q::contains)
        if (asksForComparison && !listOf(" vs ", "różnic", "roznic", "porówn", "porown", "zalet", "wad").any(a.lowercase(Locale.ROOT)::contains)) warnings += "Możliwy brak właściwego porównania."
        if (a.contains("[TODO]", true) || a.contains("<uzupełnij>", true)) warnings += "Odpowiedź zawiera niewypełniony placeholder."
        return Result(warnings.isEmpty(), warnings)
    }
}
