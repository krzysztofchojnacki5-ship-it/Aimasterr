package pl.aimasterpro.app.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Stores provider secrets encrypted with an Android Keystore AES-GCM key with auto-recovery on key invalidation. */
class SecureStore(context: Context) {
    private val prefs = context.getSharedPreferences("secure_provider_store", Context.MODE_PRIVATE)
    private val alias = "ai_master_provider_key_v1"

    @Synchronized private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        return runCatching {
            (store.getKey(alias, null) as? SecretKey)?.let { return it }
            generateNewKey()
        }.getOrElse {
            runCatching { store.deleteEntry(alias) }
            generateNewKey()
        }
    }

    private fun generateNewKey(): SecretKey {
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }

    fun putSecret(name: String, value: String) {
        if (value.isBlank()) { prefs.edit().remove(name).apply(); return }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val packed = cipher.iv + encrypted
        prefs.edit().putString(name, Base64.encodeToString(packed, Base64.NO_WRAP)).apply()
    }

    fun getSecret(name: String): String? = runCatching {
        val packed = Base64.decode(prefs.getString(name, null), Base64.NO_WRAP)
        val iv = packed.copyOfRange(0, 12)
        val ciphertext = packed.copyOfRange(12, packed.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        String(cipher.doFinal(ciphertext), Charsets.UTF_8)
    }.getOrNull()

    fun saveConfig(config: JSONObject) {
        val id = config.optString("id", "default")
        putSecret("key_$id", config.optString("apiKey"))
        val safe = JSONObject(config.toString())
        safe.remove("apiKey")
        val ids = (prefs.getStringSet("provider_ids", emptySet()) ?: emptySet()).toMutableSet()
        ids.add(id)
        prefs.edit().putString("config_$id", safe.toString()).putStringSet("provider_ids", ids).apply()
    }

    fun allConfigs(): List<JSONObject> {
        val ids = (prefs.getStringSet("provider_ids", emptySet()) ?: emptySet()).toList().sorted()
        return ids.mapNotNull { readConfig(it) }
    }

    fun replaceAllConfigs(configs: List<JSONObject>) {
        val oldIds = (prefs.getStringSet("provider_ids", emptySet()) ?: emptySet()).toSet()
        oldIds.forEach { id -> prefs.edit().remove("config_$id").apply(); putSecret("key_$id", "") }
        prefs.edit().putStringSet("provider_ids", emptySet()).apply()
        configs.forEach { saveConfig(JSONObject(it.toString())) }
    }

    fun readConfig(id: String): JSONObject? = runCatching {
        JSONObject(prefs.getString("config_$id", null) ?: return null).apply {
            put("apiKey", getSecret("key_$id") ?: "")
        }
    }.getOrNull()
}
