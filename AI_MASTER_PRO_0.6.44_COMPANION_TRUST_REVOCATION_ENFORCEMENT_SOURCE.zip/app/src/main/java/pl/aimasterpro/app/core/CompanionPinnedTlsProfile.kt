package pl.aimasterpro.app.core

import java.net.InetAddress
import java.security.KeyStore
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import java.util.IdentityHashMap
import javax.net.ssl.SSLServerSocket
import javax.net.ssl.SSLSession
import javax.net.ssl.SSLSocket

/** Opaque one-time capability issued only after this profile completes a pinned mTLS handshake. */
interface CompanionTlsPeerReceipt

/** The local endpoint role determines which pairing identity must match the authenticated peer. */
enum class CompanionTlsLocalRole { CLIENT, SERVER }

/** A completed connection and its unforgeable, single-use TLS peer proof. */
data class CompanionTlsConnection internal constructor(
    val socket: SSLSocket,
    val receipt: CompanionTlsPeerReceipt
)

/**
 * Owns the pinned SSLContext and every socket from which it may issue peer receipts.
 * Callers cannot submit arbitrary SSLSession objects or sockets from a trust-all context.
 */
class CompanionPinnedTlsProfile private constructor(
    private val context: javax.net.ssl.SSLContext,
    private val pinsByPeerId: Map<String, Set<CompanionSpkiSha256Pin>>
) {
    private data class IssuedPeer(
        val pairingSessionId: String,
        val peerId: String,
        val role: CompanionTlsLocalRole,
        val pin: CompanionSpkiSha256Pin,
        val tlsSessionId: ByteArray,
        val tlsSession: SSLSession
    )

    private class Receipt : CompanionTlsPeerReceipt

    private val serverSockets = IdentityHashMap<SSLServerSocket, Boolean>()
    private val issued = IdentityHashMap<CompanionTlsPeerReceipt, IssuedPeer>()

    /** Creates, configures and registers a server socket owned by this pinned profile. */
    @Synchronized
    fun bindServer(port: Int, backlog: Int = 16, address: InetAddress? = null): SSLServerSocket {
        require(port in 0..65535)
        require(backlog in 1..128)
        synchronized(this) {
            check(serverSockets.size < MAX_SERVER_SOCKETS) { "Limit gniazd serwera Companion został osiągnięty." }
        }
        val socket = if (address == null) {
            context.serverSocketFactory.createServerSocket(port, backlog)
        } else {
            context.serverSocketFactory.createServerSocket(port, backlog, address)
        } as? SSLServerSocket ?: throw IllegalStateException("Dostawca TLS nie utworzył SSLServerSocket.")
        try {
            CompanionTlsContext.configureMutualTlsServerSocket(socket)
            serverSockets[socket] = true
            return socket
        } catch (error: RuntimeException) {
            try { socket.close() } catch (_: Exception) { }
            throw error
        }
    }

    /** Closes and unregisters a server socket created by this profile. */
    @Synchronized
    fun closeServer(server: SSLServerSocket) {
        if (serverSockets.remove(server) == null) return
        try { server.close() } catch (_: Exception) { }
    }

    /** Accepts exactly one peer, completes the TLS handshake and issues a bound one-time receipt. */
    fun accept(
        server: SSLServerSocket,
        pairingSessionId: String,
        expectedPeerId: String,
        timeoutMs: Int = 5_000
    ): CompanionTlsConnection {
        synchronized(this) {
            check(serverSockets.containsKey(server)) { "Gniazdo serwera nie należy do tego profilu TLS." }
        }
        requireValidBinding(pairingSessionId, expectedPeerId)
        require(timeoutMs in 1..60_000)
        server.soTimeout = timeoutMs
        val socket = server.accept() as? SSLSocket
            ?: throw IllegalStateException("Dostawca TLS nie zaakceptował SSLSocket.")
        return establish(socket, pairingSessionId, expectedPeerId, CompanionTlsLocalRole.SERVER, timeoutMs)
    }

    /** Connects, completes the TLS handshake and issues a bound one-time receipt. */
    fun connect(
        expectedHost: String,
        port: Int,
        pairingSessionId: String,
        expectedPeerId: String,
        timeoutMs: Int = 5_000
    ): CompanionTlsConnection {
        requireValidBinding(pairingSessionId, expectedPeerId)
        require(timeoutMs in 1..60_000)
        val socket = CompanionTlsContext.openClientSocket(context, expectedHost, port, timeoutMs)
        return establish(socket, pairingSessionId, expectedPeerId, CompanionTlsLocalRole.CLIENT, timeoutMs)
    }

    /** Consumes the exact receipt once and returns only metadata validated by this profile. */
    @Synchronized
    internal fun consume(receipt: CompanionTlsPeerReceipt): PeerIdentity? {
        val peer = issued.remove(receipt) ?: return null
        if (!peer.tlsSession.isValid || !peer.tlsSession.id.contentEquals(peer.tlsSessionId)) return null
        return PeerIdentity(peer.pairingSessionId, peer.peerId, peer.role, peer.pin, peer.tlsSessionId.copyOf())
    }

    internal data class PeerIdentity(
        val pairingSessionId: String,
        val peerId: String,
        val role: CompanionTlsLocalRole,
        val pin: CompanionSpkiSha256Pin,
        val tlsSessionId: ByteArray
    )

    private fun establish(
        socket: SSLSocket,
        pairingSessionId: String,
        expectedPeerId: String,
        role: CompanionTlsLocalRole,
        timeoutMs: Int
    ): CompanionTlsConnection {
        try {
            socket.soTimeout = timeoutMs
            socket.startHandshake()
            val session = socket.session
            require(session.isValid) { "Sesja TLS nie jest prawidłowa." }
            require(session.protocol == "TLSv1.2" || session.protocol == "TLSv1.3") {
                "Niedozwolona wersja TLS."
            }
            val leaf = session.peerCertificates.firstOrNull() as? X509Certificate
                ?: throw CertificateException("Brak certyfikatu X.509 peer.")
            val pin = CompanionSpkiSha256Pin.fromCertificate(leaf)
            val expectedPins = pinsByPeerId[expectedPeerId]
                ?: throw CertificateException("Brak provisioningu SPKI dla identyfikatora peer.")
            if (expectedPins.none { it == pin }) throw CertificateException("SPKI peer nie pasuje do przypiętej tożsamości.")
            val receipt = Receipt()
            synchronized(this) {
                check(issued.size < MAX_RECEIPTS) { "Limit nieodebranych potwierdzeń TLS został osiągnięty." }
                issued[receipt] = IssuedPeer(
                    pairingSessionId, expectedPeerId, role, pin, session.id.copyOf(), session
                )
            }
            return CompanionTlsConnection(socket, receipt)
        } catch (error: Exception) {
            try { socket.close() } catch (_: Exception) { }
            throw error
        }
    }

    private fun requireValidBinding(sessionId: String, peerId: String) {
        require(sessionId.matches(Regex("[A-Za-z0-9._-]{1,80}"))) { "Nieprawidłowy identyfikator sesji parowania." }
        require(peerId.matches(Regex("[A-Za-z0-9._-]{1,80}"))) { "Nieprawidłowy identyfikator peer." }
    }

    companion object {
        const val MAX_RECEIPTS = 32
        const val MAX_SERVER_SOCKETS = 8

        /** Creates a profile whose SSLContext and pin set remain private to the profile. */
        fun create(
            identityKeyStore: KeyStore,
            keyPassword: CharArray?,
            trustStore: KeyStore,
            pinsByPeerId: Map<String, Set<CompanionSpkiSha256Pin>>
        ): CompanionPinnedTlsProfile {
            require(pinsByPeerId.isNotEmpty() && pinsByPeerId.all { (id, pins) ->
                id.matches(Regex("[A-Za-z0-9._-]{1,80}")) && pins.isNotEmpty()
            }) { "Każdy identyfikator peer musi mieć niepusty zestaw pinów SPKI." }
            val immutablePins = pinsByPeerId.mapValues { it.value.toSet() }.toMap()
            val context = CompanionTlsContext.createPinnedMutualTlsContext(
                identityKeyStore, keyPassword, trustStore, immutablePins.values.flatten().toSet()
            )
            return CompanionPinnedTlsProfile(context, immutablePins)
        }
    }
}
