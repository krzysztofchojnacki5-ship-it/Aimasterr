package pl.aimasterpro.app.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Audit ledger for proposed changes. It records approvals/tests but deliberately does not apply patches. */
object ChangeSetStore {
    private const val PREFS = "ai_change_set_ledger_v1"
    private const val KEY = "changes"
    private const val MAX_ITEMS = 100
    private val statuses = setOf("PROPOSED", "APPROVED", "APPLIED_UNVERIFIED", "REJECTED", "APPLIED", "ROLLED_BACK")

    data class ChangeSet(
        val id: String, val taskId: String, val summary: String, val paths: List<String>,
        val status: String, val testStatus: String, val testOutput: String,
        val createdAt: Long, val updatedAt: Long, val validationCodes: List<String>, val snapshotId: String = "", val testLevel: String = "NONE"
    )

    @Synchronized fun all(context: Context): List<ChangeSet> = read(context)

    @Synchronized fun propose(context: Context, taskId: String, summary: String, paths: List<String>, validation: ChangeSafetyGuard.Validation): ChangeSet {
        require(taskId.isNotBlank()) { "Brak identyfikatora zadania" }
        require(summary.isNotBlank()) { "Brak opisu zmian" }
        require(validation.allowed) { "Nie można zarejestrować zestawu z blokującymi błędami walidacji" }
        val suppliedPaths = paths.map { it.trim().replace('\\', '/') }.toSet()
        require(suppliedPaths.isNotEmpty() && suppliedPaths == validation.normalizedPaths.toSet() && suppliedPaths.size == paths.size) {
            "Ścieżki rejestru muszą dokładnie odpowiadać ścieżkom zweryfikowanym przez ChangeSafetyGuard."
        }
        val now = System.currentTimeMillis()
        val item = ChangeSet(UUID.randomUUID().toString(), taskId.take(160), summary.take(2000),
            validation.normalizedPaths.distinct().take(50), "PROPOSED", "NOT_RUN", "", now, now,
            validation.findings.map { it.code }.distinct().take(50))
        write(context, (listOf(item) + read(context)).take(MAX_ITEMS))
        return item
    }

    @Synchronized fun transition(context: Context, id: String, next: String): Boolean {
        require(next in statuses) { "Nieznany status zestawu zmian" }
        val rows = read(context).toMutableList()
        val index = rows.indexOfFirst { it.id == id }
        if (index < 0) return false
        val current = rows[index].status
        val allowed = when (current) {
            "PROPOSED" -> setOf("APPROVED", "REJECTED")
            "APPROVED" -> setOf("APPLIED_UNVERIFIED", "REJECTED")
            "APPLIED_UNVERIFIED" -> setOf("APPLIED", "ROLLED_BACK")
            "APPLIED" -> setOf("ROLLED_BACK")
            else -> emptySet()
        }
        if (next == current) return true
        require(next in allowed) { "Niedozwolona zmiana statusu: $current → $next" }
        if (next == "APPLIED_UNVERIFIED" || next == "APPLIED") {
            require(rows[index].snapshotId.isNotBlank()) { "Nie można oznaczyć zmiany jako zastosowanej bez powiązanego snapshotu." }
        }
        if (next == "APPLIED") {
            require(rows[index].testStatus == "PASS" && rows[index].testLevel == "PROJECT_TESTS") {
                "Nie można oznaczyć zmiany jako APPLIED bez PASS rzeczywistych testów projektu w izolowanym executorze."
            }
        }
        rows[index] = rows[index].copy(status = next, updatedAt = System.currentTimeMillis())
        write(context, rows)
        return true
    }

    @Synchronized fun recordSnapshot(context: Context, id: String, snapshotId: String): Boolean {
        require(snapshotId.isNotBlank()) { "Brak identyfikatora snapshotu" }
        val rows = read(context).toMutableList()
        val index = rows.indexOfFirst { it.id == id }
        if (index < 0) return false
        val item = rows[index]
        require(item.status == "APPROVED" || item.status == "APPLIED_UNVERIFIED") {
            "Snapshot można przypisać wyłącznie do zmiany zatwierdzonej lub oczekującej na weryfikację."
        }
        rows[index] = item.copy(snapshotId = snapshotId.take(160), updatedAt = System.currentTimeMillis())
        write(context, rows)
        return true
    }

    /** Legacy/manual reports are never sufficient evidence for APPLIED. */
    @Synchronized fun recordTests(context: Context, id: String, passed: Boolean, output: String): Boolean =
        recordVerificationInternal(context, id, if (passed) "PASS" else "FAIL", "LEGACY_UNVERIFIED", output)

    /**
     * Persists only local workspace-integrity results. Callers cannot label arbitrary output
     * as PROJECT_TESTS; that level is reserved for a future verified executor receipt.
     */
    @Synchronized fun recordWorkspaceVerification(context: Context, id: String, status: String, output: String): Boolean =
        recordVerificationInternal(context, id, status, "WORKSPACE_INTEGRITY", output)

    @Synchronized private fun recordVerificationInternal(context: Context, id: String, status: String, level: String, output: String): Boolean {
        require(status in setOf("PASS", "FAIL", "NOT_RUN")) { "Nieznany status testów" }
        require(level in setOf("WORKSPACE_INTEGRITY", "LEGACY_UNVERIFIED")) { "Poziom PROJECT_TESTS wymaga zweryfikowanego executor receipt." }
        val rows = read(context).toMutableList()
        val index = rows.indexOfFirst { it.id == id }
        if (index < 0) return false
        val item = rows[index]
        require(item.status == "APPROVED" || item.status == "APPLIED_UNVERIFIED") {
            "Wyniku weryfikacji nie można nadpisywać po końcowym statusie APPLIED."
        }
        rows[index] = item.copy(testStatus = status, testLevel = level, testOutput = output.take(8000), updatedAt = System.currentTimeMillis())
        write(context, rows)
        return true
    }

    private fun read(context: Context): List<ChangeSet> = runCatching {
        val a = JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]")
        (0 until a.length()).mapNotNull { i ->
            val o = a.optJSONObject(i) ?: return@mapNotNull null
            val id = o.optString("id")
            val status = o.optString("status")
            if (id.isBlank() || status !in statuses) null else {
                // 0.6.19 had no isolated executor. Any persisted PROJECT_TESTS label from that
                // generation is untrusted and must not unlock APPLIED after upgrade.
                val storedLevel = o.optString("testLevel", "NONE")
                val safeLevel = if (storedLevel == "PROJECT_TESTS") "LEGACY_UNVERIFIED" else storedLevel
                val safeStatus = if (storedLevel == "PROJECT_TESTS") "NOT_RUN" else o.optString("testStatus", "NOT_RUN")
                ChangeSet(id, o.optString("taskId"), o.optString("summary"),
                    strings(o.optJSONArray("paths")), status, safeStatus, o.optString("testOutput"),
                    o.optLong("createdAt"), o.optLong("updatedAt"), strings(o.optJSONArray("validationCodes")), o.optString("snapshotId"), safeLevel)
            }
        }
    }.getOrDefault(emptyList())

    private fun write(context: Context, rows: List<ChangeSet>) {
        val a = JSONArray()
        rows.take(MAX_ITEMS).forEach { c -> a.put(JSONObject().put("id", c.id).put("taskId", c.taskId)
            .put("summary", c.summary).put("paths", JSONArray(c.paths)).put("status", c.status)
            .put("testStatus", c.testStatus).put("testOutput", c.testOutput).put("createdAt", c.createdAt)
            .put("updatedAt", c.updatedAt).put("validationCodes", JSONArray(c.validationCodes)).put("snapshotId", c.snapshotId)
            .put("testLevel", c.testLevel)) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply()
    }

    private fun strings(a: JSONArray?): List<String> = if (a == null) emptyList() else
        (0 until a.length()).mapNotNull { a.optString(it).takeIf(String::isNotBlank) }
}
