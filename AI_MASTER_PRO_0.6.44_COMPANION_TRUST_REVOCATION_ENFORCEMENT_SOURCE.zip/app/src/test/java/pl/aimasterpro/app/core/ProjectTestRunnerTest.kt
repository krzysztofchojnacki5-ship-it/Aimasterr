package pl.aimasterpro.app.core

import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ProjectTestRunnerTest {
    private fun zip(vararg files: Pair<String, String>): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip -> files.forEach { (path, content) ->
            zip.putNextEntry(ZipEntry(path)); zip.write(content.toByteArray()); zip.closeEntry()
        } }
        return out.toByteArray()
    }

    @Test fun safeRunnerReportsNotRunEvenWhenIntegrityChecksPass() {
        val root = Files.createTempDirectory("aimaster-runner").toFile()
        val store = ProjectWorkspaceStore(root)
        store.importZip(ByteArrayInputStream(zip("README.md" to "before\n")), "fixture.zip")
        val patch = ProjectPatchEngine.preview(
            listOf(ProjectPatchEngine.Proposal("README.md", store.readTextFile("README.md").sha256,
                "--- a/README.md\n+++ b/README.md\n@@ -1 +1 @@\n-before\n+after\n")),
            store.listFiles()
        ) { path, limit -> store.readTextFile(path, limit) }
        assertTrue(patch.accepted)
        val applied = store.applyPreview(patch)
        val result = ProjectTestRunner(store).verifyAppliedChange(applied.snapshot.id, applied.changedPaths)
        assertEquals(ProjectTestRunner.Status.NOT_RUN, result.status)
        assertFalse(result.projectCodeExecuted)
        assertTrue(result.checks.filter { it.name != "PROJECT_TESTS" }.all { it.status == ProjectTestRunner.Status.PASS })
        assertEquals(ProjectTestRunner.Status.NOT_RUN, result.checks.single { it.name == "PROJECT_TESTS" }.status)
    }

    @Test fun runnerDetectsUnexpectedWorkspaceModification() {
        val root = Files.createTempDirectory("aimaster-runner-fail").toFile()
        val store = ProjectWorkspaceStore(root)
        store.importZip(ByteArrayInputStream(zip("README.md" to "before\n")), "fixture.zip")
        val patch = ProjectPatchEngine.preview(
            listOf(ProjectPatchEngine.Proposal("README.md", store.readTextFile("README.md").sha256,
                "--- a/README.md\n+++ b/README.md\n@@ -1 +1 @@\n-before\n+after\n")),
            store.listFiles()
        ) { path, limit -> store.readTextFile(path, limit) }
        val applied = store.applyPreview(patch)
        java.io.File(root, "current/README.md").writeText("tampered\n")
        val result = ProjectTestRunner(store).verifyAppliedChange(applied.snapshot.id, applied.changedPaths)
        assertEquals(ProjectTestRunner.Status.FAIL, result.status)
        assertTrue(result.checks.any { it.name == "WORKSPACE_INTEGRITY" && it.status == ProjectTestRunner.Status.FAIL })
    }

    @Test fun runnerRejectsUnsafeOrDuplicatedChangeSetPaths() {
        val root = Files.createTempDirectory("aimaster-runner-paths").toFile()
        val store = ProjectWorkspaceStore(root)
        store.importZip(ByteArrayInputStream(zip("README.md" to "before\n")), "fixture.zip")
        val patch = ProjectPatchEngine.preview(
            listOf(ProjectPatchEngine.Proposal("README.md", store.readTextFile("README.md").sha256,
                "--- a/README.md\n+++ b/README.md\n@@ -1 +1 @@\n-before\n+after\n")),
            store.listFiles()
        ) { path, limit -> store.readTextFile(path, limit) }
        val applied = store.applyPreview(patch)
        val result = ProjectTestRunner(store).verifyAppliedChange(applied.snapshot.id, listOf("README.md", "../outside"))
        assertEquals(ProjectTestRunner.Status.FAIL, result.status)
        assertTrue(result.checks.any { it.name == "PATCH_SCOPE" && it.status == ProjectTestRunner.Status.FAIL })
        assertFalse(result.projectCodeExecuted)
    }

}
