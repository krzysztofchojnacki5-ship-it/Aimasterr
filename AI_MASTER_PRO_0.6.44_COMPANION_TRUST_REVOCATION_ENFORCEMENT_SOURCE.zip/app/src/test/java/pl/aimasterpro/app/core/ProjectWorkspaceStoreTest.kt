package pl.aimasterpro.app.core

import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ProjectWorkspaceStoreTest {
    private fun tempDir(prefix: String): File = java.nio.file.Files.createTempDirectory(prefix).toFile()

    private fun zip(vararg entries: Pair<String, String>): ByteArray {
        val bytes = ByteArrayOutputStream()
        ZipOutputStream(bytes).use { out ->
            entries.forEach { (name, content) ->
                out.putNextEntry(ZipEntry(name))
                out.write(content.toByteArray())
                out.closeEntry()
            }
        }
        return bytes.toByteArray()
    }

    @Test fun importsFilesAndCreatesManifestWithHashes() {
        val root = tempDir("workspace-import-")
        try {
            val store = ProjectWorkspaceStore(root)
            val info = store.importZip(ByteArrayInputStream(zip("app/src/Main.kt" to "fun main() {}", "README.md" to "hello")), "project.zip", 100L)
            assertEquals(2, info.fileCount)
            assertEquals(100L, store.currentInfo()?.importedAt)
            assertEquals(2, store.listFiles().size)
            assertEquals("fun main() {}", File(root, "current/app/src/Main.kt").readText())
            assertTrue(info.files.all { it.sha256.matches(Regex("[0-9a-f]{64}")) })
            assertTrue(store.verifyCurrentWorkspace().valid)
        } finally { root.deleteRecursively() }
    }

    @Test fun rejectsZipSlipAndLeavesExistingWorkspaceUntouched() {
        val root = tempDir("workspace-slip-")
        try {
            val store = ProjectWorkspaceStore(root)
            store.importZip(ByteArrayInputStream(zip("README.md" to "safe")), "safe.zip", 1L)
            val failure = runCatching { store.importZip(ByteArrayInputStream(zip("../escape.txt" to "bad")), "bad.zip", 2L) }
            assertTrue(failure.isFailure)
            assertEquals("safe", File(root, "current/README.md").readText())
            assertFalse(File(root.parentFile, "escape.txt").exists())
        } finally { root.deleteRecursively() }
    }

    @Test fun excludesSecretsAndBuildArtifacts() {
        val root = tempDir("workspace-filter-")
        try {
            val store = ProjectWorkspaceStore(root)
            val info = store.importZip(ByteArrayInputStream(zip(
                "app/src/Main.kt" to "source",
                "local.properties" to "sdk.dir=/secret",
                ".env.production" to "API_KEY=secret",
                ".env/private.txt" to "API_KEY=nested-secret",
                "build/output.apk" to "binary",
                ".git/config" to "git metadata"
            )), "project.zip")
            assertEquals(listOf("app/src/Main.kt"), info.files.map { it.path })
        } finally { root.deleteRecursively() }
    }

    @Test fun rejectsDuplicatePathsCaseInsensitively() {
        val root = tempDir("workspace-duplicate-")
        try {
            val bytes = zip("src/Main.kt" to "one", "SRC/main.kt" to "two")
            assertTrue(runCatching { ProjectWorkspaceStore(root).importZip(ByteArrayInputStream(bytes), "dup.zip") }.isFailure)
        } finally { root.deleteRecursively() }
    }

    @Test fun secondImportSnapshotsPreviousWorkspace() {
        val root = tempDir("workspace-snapshot-")
        try {
            val store = ProjectWorkspaceStore(root)
            store.importZip(ByteArrayInputStream(zip("README.md" to "version one")), "one.zip", 10L)
            store.importZip(ByteArrayInputStream(zip("README.md" to "version two")), "two.zip", 20L)
            assertEquals("version two", File(root, "current/README.md").readText())
            val snapshots = store.snapshots()
            assertEquals(1, snapshots.size)
            assertEquals("version one", File(root, "snapshots/${snapshots.first().id}/project/README.md").readText())
            assertEquals(20L, snapshots.first().createdAt)
        } finally { root.deleteRecursively() }
    }


    @Test fun integrityCheckDetectsModifiedAndUnexpectedFiles() {
        val root = tempDir("workspace-integrity-")
        try {
            val store = ProjectWorkspaceStore(root)
            store.importZip(ByteArrayInputStream(zip("src/Main.kt" to "original")), "project.zip")
            File(root, "current/src/Main.kt").writeText("tampered")
            File(root, "current/extra.txt").writeText("unexpected")
            val report = store.verifyCurrentWorkspace()
            assertFalse(report.valid)
            assertEquals(listOf("src/Main.kt"), report.modified)
            assertEquals(listOf("extra.txt"), report.unexpected)
        } finally { root.deleteRecursively() }
    }

    @Test fun rejectsEmptyArchiveWithoutReplacingWorkspace() {
        val root = tempDir("workspace-empty-")
        try {
            val store = ProjectWorkspaceStore(root)
            store.importZip(ByteArrayInputStream(zip("README.md" to "keep")), "one.zip")
            val empty = ByteArrayOutputStream().also { ZipOutputStream(it).close() }.toByteArray()
            assertTrue(runCatching { store.importZip(ByteArrayInputStream(empty), "empty.zip") }.isFailure)
            assertEquals("keep", File(root, "current/README.md").readText())
        } finally { root.deleteRecursively() }
    }
    @Test fun readsOnlyManifestOwnedUtf8TextAfterHashVerification() {
        val root = tempDir("workspace-read-")
        try {
            val store = ProjectWorkspaceStore(root)
            store.importZip(ByteArrayInputStream(zip("app/src/Main.kt" to "fun main() = Unit", "image.png" to "not-text")), "project.zip")
            val read = store.readTextFile("app/src/Main.kt")
            assertEquals("fun main() = Unit", read.content)
            assertEquals(64, read.sha256.length)
            assertTrue(runCatching { store.readTextFile("../outside.kt") }.isFailure)
            assertTrue(runCatching { store.readTextFile("image.png") }.isFailure)
            assertTrue(runCatching { store.readTextFile("missing.kt") }.isFailure)
        } finally { root.deleteRecursively() }
    }

    @Test fun refusesToReadTamperedSourceAndDoesNotSnapshotTamperedWorkspace() {
        val root = tempDir("workspace-tamper-")
        try {
            val store = ProjectWorkspaceStore(root)
            store.importZip(ByteArrayInputStream(zip("src/Main.kt" to "original")), "one.zip", 10L)
            File(root, "current/src/Main.kt").writeText("tampered")
            assertTrue(runCatching { store.readTextFile("src/Main.kt") }.isFailure)
            val next = runCatching { store.importZip(ByteArrayInputStream(zip("README.md" to "next")), "two.zip", 20L) }
            assertTrue(next.isFailure)
            assertEquals("tampered", File(root, "current/src/Main.kt").readText())
            assertTrue(store.snapshots().isEmpty())
        } finally { root.deleteRecursively() }
    }

    @Test fun blocksSecretLikeTextFromPreview() {
        val root = tempDir("workspace-secret-preview-")
        try {
            val store = ProjectWorkspaceStore(root)
            store.importZip(ByteArrayInputStream(zip("gradle.properties" to "apiKey=abcdefghijklmnopqrstuvwxyz012345")), "project.zip")
            assertTrue(runCatching { store.readTextFile("gradle.properties") }.isFailure)
        } finally { root.deleteRecursively() }
    }

    @Test fun blocksApiTokenAndPrivateKeyPatternsFromPreview() {
        val root = tempDir("workspace-secret-variants-")
        try {
            val store = ProjectWorkspaceStore(root)
            store.importZip(ByteArrayInputStream(zip(
                "config/one.properties" to "api_token=abcdefghijklmno12345",
                "config/two.properties" to "private_key=abcdefghijklmno12345"
            )), "secrets.zip")
            assertTrue(runCatching { store.readTextFile("config/one.properties") }.isFailure)
            assertTrue(runCatching { store.readTextFile("config/two.properties") }.isFailure)
        } finally { root.deleteRecursively() }
    }

    @Test fun integrityCheckRejectsSymbolicLinks() {
        val root = tempDir("workspace-symlink-")
        val outside = File(root.parentFile, "workspace-outside-${System.nanoTime()}.txt")
        try {
            val store = ProjectWorkspaceStore(root)
            store.importZip(ByteArrayInputStream(zip("src/Main.kt" to "safe")), "project.zip")
            outside.writeText("outside")
            val target = File(root, "current/src/Main.kt")
            target.delete()
            java.nio.file.Files.createSymbolicLink(target.toPath(), outside.toPath())
            val report = store.verifyCurrentWorkspace()
            assertFalse(report.valid)
            assertTrue(report.missing.contains("src/Main.kt"))
        } finally {
            root.deleteRecursively()
            outside.delete()
        }
    }

}
