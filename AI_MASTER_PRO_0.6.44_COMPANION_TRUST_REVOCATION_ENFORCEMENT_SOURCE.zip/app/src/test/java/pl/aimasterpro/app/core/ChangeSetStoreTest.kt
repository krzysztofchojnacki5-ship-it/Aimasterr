package pl.aimasterpro.app.core

import android.content.Context
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.json.JSONArray
import org.json.JSONObject

@RunWith(RobolectricTestRunner::class)
class ChangeSetStoreTest {
    private val context get() = RuntimeEnvironment.getApplication()
    @Before fun reset() { context.getSharedPreferences("ai_change_set_ledger_v1", Context.MODE_PRIVATE).edit().clear().commit() }

    @Test fun enforcesApprovalTestAndRollbackStateMachine() {
        val item = ChangeSetStore.propose(context, "task-1", "Zmiana ekranu", listOf("app/src/Main.kt"), ChangeSafetyGuard.validate(listOf("app/src/Main.kt")))
        assertEquals("PROPOSED", item.status)
        assertTrue(ChangeSetStore.transition(context, item.id, "APPROVED"))
        assertTrue(ChangeSetStore.recordSnapshot(context, item.id, "snapshot-1"))
        assertTrue(ChangeSetStore.transition(context, item.id, "APPLIED_UNVERIFIED"))
        assertTrue(ChangeSetStore.recordTests(context, item.id, true, "ręczny raport: 3 testy passed"))
        assertEquals("LEGACY_UNVERIFIED", ChangeSetStore.all(context).single().testLevel)
        assertThrows(IllegalArgumentException::class.java) { ChangeSetStore.transition(context, item.id, "APPLIED") }
        assertTrue(ChangeSetStore.transition(context, item.id, "ROLLED_BACK"))
        assertEquals("ROLLED_BACK", ChangeSetStore.all(context).single().status)
    }

    @Test(expected = IllegalArgumentException::class)
    fun blocksApplyingBeforeTestsPass() {
        val item = ChangeSetStore.propose(context, "task-no-tests", "Zmiana", listOf("app/src/A.kt"), ChangeSafetyGuard.validate(listOf("app/src/A.kt")))
        ChangeSetStore.transition(context, item.id, "APPROVED")
        ChangeSetStore.transition(context, item.id, "APPLIED")
    }

    @Test(expected = IllegalArgumentException::class)
    fun blocksApplyingWithoutApproval() {
        val item = ChangeSetStore.propose(context, "task-2", "Zmiana", listOf("app/src/A.kt"), ChangeSafetyGuard.validate(listOf("app/src/A.kt")))
        ChangeSetStore.transition(context, item.id, "APPLIED")
    }

    @Test(expected = IllegalArgumentException::class)
    fun refusesUnsafeProposal() {
        ChangeSetStore.propose(context, "task-3", "Unsafe", listOf("../outside"), ChangeSafetyGuard.validate(listOf("../outside")))
    }
    @Test fun allowsAppliedUnverifiedUntilIsolatedTestsFinish() {
        val item = ChangeSetStore.propose(context, "task-unverified", "Patch workspace", listOf("app/src/A.kt"), ChangeSafetyGuard.validate(listOf("app/src/A.kt")))
        assertTrue(ChangeSetStore.transition(context, item.id, "APPROVED"))
        assertTrue(ChangeSetStore.recordSnapshot(context, item.id, "snapshot-123"))
        assertTrue(ChangeSetStore.transition(context, item.id, "APPLIED_UNVERIFIED"))
        assertEquals("snapshot-123", ChangeSetStore.all(context).single().snapshotId)
        assertEquals("APPLIED_UNVERIFIED", ChangeSetStore.all(context).single().status)
        assertTrue(ChangeSetStore.recordTests(context, item.id, true, "manual claim: isolated project tests passed"))
        assertThrows(IllegalArgumentException::class.java) { ChangeSetStore.transition(context, item.id, "APPLIED") }
        assertEquals("APPLIED_UNVERIFIED", ChangeSetStore.all(context).single().status)
    }

    @Test fun workspaceIntegrityPassCannotPromoteChangeToApplied() {
        val item = ChangeSetStore.propose(context, "task-integrity-only", "Patch workspace", listOf("app/src/A.kt"), ChangeSafetyGuard.validate(listOf("app/src/A.kt")))
        ChangeSetStore.transition(context, item.id, "APPROVED")
        ChangeSetStore.recordSnapshot(context, item.id, "snapshot-integrity")
        ChangeSetStore.transition(context, item.id, "APPLIED_UNVERIFIED")
        ChangeSetStore.recordWorkspaceVerification(context, item.id, "PASS", "Manifest and snapshot match")
        assertThrows(IllegalArgumentException::class.java) { ChangeSetStore.transition(context, item.id, "APPLIED") }
    }

    @Test fun notRunIsPersistedWithoutClaimingSuccess() {
        val item = ChangeSetStore.propose(context, "task-not-run", "Patch workspace", listOf("app/src/A.kt"), ChangeSafetyGuard.validate(listOf("app/src/A.kt")))
        ChangeSetStore.transition(context, item.id, "APPROVED")
        ChangeSetStore.recordSnapshot(context, item.id, "snapshot-not-run")
        ChangeSetStore.transition(context, item.id, "APPLIED_UNVERIFIED")
        ChangeSetStore.recordWorkspaceVerification(context, item.id, "NOT_RUN", "Project tests unavailable")
        val saved = ChangeSetStore.all(context).single()
        assertEquals("NOT_RUN", saved.testStatus)
        assertEquals("WORKSPACE_INTEGRITY", saved.testLevel)
    }

    @Test fun unverifiedAppliedChangeCanBeRolledBack() {
        val item = ChangeSetStore.propose(context, "task-unverified-rollback", "Patch workspace", listOf("app/src/A.kt"), ChangeSafetyGuard.validate(listOf("app/src/A.kt")))
        ChangeSetStore.transition(context, item.id, "APPROVED")
        ChangeSetStore.recordSnapshot(context, item.id, "snapshot-rollback")
        ChangeSetStore.transition(context, item.id, "APPLIED_UNVERIFIED")
        assertTrue(ChangeSetStore.transition(context, item.id, "ROLLED_BACK"))
    }


    @Test fun downgradesLegacyProjectTestClaimFromPreExecutorVersion() {
        val item = ChangeSetStore.propose(context, "task-legacy-pass", "Patch", listOf("app/src/A.kt"), ChangeSafetyGuard.validate(listOf("app/src/A.kt")))
        ChangeSetStore.transition(context, item.id, "APPROVED")
        ChangeSetStore.recordSnapshot(context, item.id, "snapshot-legacy")
        ChangeSetStore.transition(context, item.id, "APPLIED_UNVERIFIED")
        val prefs = context.getSharedPreferences("ai_change_set_ledger_v1", Context.MODE_PRIVATE)
        val rows = JSONArray(prefs.getString("changes", "[]"))
        rows.getJSONObject(0).put("testStatus", "PASS").put("testLevel", "PROJECT_TESTS")
        prefs.edit().putString("changes", rows.toString()).commit()

        val loaded = ChangeSetStore.all(context).single()
        assertEquals("NOT_RUN", loaded.testStatus)
        assertEquals("LEGACY_UNVERIFIED", loaded.testLevel)
        assertThrows(IllegalArgumentException::class.java) { ChangeSetStore.transition(context, item.id, "APPLIED") }
    }

}
