# AI MASTER PRO — przekazanie prac (stan 0.6.44)

Kontynuuj istniejący projekt Android `AI_MASTER_PRO_ANDROID`, nie twórz go od nowa. Zachowaj dotychczasową architekturę i numerację roadmapy. Użytkownik oczekuje samodzielnego prowadzenia kolejnych kroków, naprawiania wykrytych błędów, testów regresji, aktualizacji changelogu/statusu/roadmapy i kompletnego ZIP źródeł. Nie deklaruj buildów ani testów urządzeniowych, których faktycznie nie wykonano.

## Aktualna baza
- Wersja: 0.6.44, versionCode 70.
- Punkt listy: 5 — trwałe provisionowanie i zaufanie Companion.
- 0.6.44 dodaje walidator zaufania do `CompanionSessionOwner`; preferowana ścieżka `CompanionProvisioningStore.createSessionOwner()` sprawdza bieżące piny z zaszyfrowanego magazynu. Aktywacja oraz kolejne operacje sesji są fail-closed po unieważnieniu/rotacji starego pinu.
- Testy TLS/Owner: 31/31 PASS, pięć powtórzeń 155/155 PASS. Wybrane klasy core + store skompilowane `kotlinc -Werror` z atrapami Android/JSON. Pełny Gradle/Robolectric i Android Keystore/device: NOT RUN.
- Ograniczenie: owner nie posiada jeszcze socketu TLS, zatem revocation jest wykrywane przy następnej operacji API ownera, nie zamyka natychmiast gniazda.

## Następne zadania (pozostań w punkcie 5)
1. Zaprojektuj bezpieczny cykl wydania/otrzymania certyfikatu TLS z SAN, zgodny z Android Keystore i zaufanym CA; nie traktuj lokalnego certyfikatu Keystore jako certyfikatu CA-issued.
2. Zaprojektuj migrację istniejącego PSK bez logowania/eksportu sekretu, z wersjonowaniem, atomowym zapisem, rollback protection i wymuszeniem ponownego parowania przy niejednoznacznym stanie.
3. Zaimplementuj jawny recovery/re-pairing: utrata klucza lub magazynu nie może powodować automatycznego odtworzenia starego zaufania.
4. Następnie rozważ własność socketu przez owner/connection handle i natychmiastowe zamykanie aktywnych połączeń po revocation. Dodaj testy wyścigów i zamykania.
5. Uruchom pełny Gradle/Robolectric i prawdziwe testy Android Keystore, gdy dostępne będzie środowisko.

Nie rozpoczynaj punktu 6 (transport) dopóki wszystkie bramki punktu 5 nie zostaną zamknięte. Desktop Companion, OS sandbox i `PROJECT_TESTS` pozostają dalszymi etapami.

## Pochodzenie
Baza 0.6.41/0.6.42 pochodzi z rekonstrukcji 0.6.40 na bazie odzyskanego 0.6.39; nie przedstawiaj jej jako oryginalnego ZIP 0.6.40.
