# AI MASTER PRO — kontrakt architektury obszaru roboczego

Ten dokument utrzymuje kolejność wdrożeń i granice bezpieczeństwa, aby następne etapy nie wymagały przebudowy importera.

## Obecny etap: 0.6.37 — właściciel cyklu życia sesji Companion

Wersje 0.6.18–0.6.19.1 dostarczyły jawne zatwierdzanie, zapis transakcyjny, crash recovery, weryfikację manifestów, rollback i bramkę zaufania. W 0.6.20 dodano wersjonowany kontrakt bundle/request/receipt, allowlistę zadań, politykę zasobów i weryfikację podpisu RSA. W 0.6.21–0.6.24 powstał eksport zweryfikowanego bundle, skan sekretów, challenge-response parowania i uwierzytelnione ramki. W 0.6.25 dodano ograniczony binarny kodek `AIMF`: parser sprawdza rozmiary przed alokacją, wersje, enumy, ścisły UTF-8, kanoniczny Base64URL i brak trailing bytes. W 0.6.26 utwardzono politykę cleartext: HTTP jest domyślnie zablokowane, z wyjątkiem dokładnych endpointów localhost/127.0.0.1 i aliasu emulatora. Audyt 0.6.26 wykazał nieograniczony odczyt odpowiedzi HTTP (`readText()`); w 0.6.27 zastąpiono go ograniczonym strumieniowym readerem 4 MiB z walidacją UTF-8. W 0.6.28 dodano fail-closed walidację endpointów dostawców i projekt TLS/mTLS Companion. W 0.6.29 naprawiono błąd DoS w parowaniu: challenge jest zużywany dopiero po poprawnym uwierzytelnieniu proof, a porównanie HMAC challenge jest stałoczasowe. W 0.6.30 odbiornik ramek egzekwuje terminalne `CLOSE`, odrzuca ramki po zamknięciu, umożliwia jawne unieważnienie i zeruje kopię klucza; wyczerpanie numeracji również kończy odbiornik. W 0.6.31 dodano niezależną politykę timeoutów handshake, idle, transferu i hard lifetime, opartą na zegarze monotonicznym; aktywność nie przedłuża maksymalnego czasu życia sesji. Polityka nie uwierzytelnia peerów i nie jest jeszcze podłączona do transportu. Testy obejmują granice timeoutów, długą fazę handshake, idempotencję znacznika handshake, brak przedłużania hard lifetime oraz zawinięcie nanoTime. Pełna maszyna stanów sesji wymaga przyszłego, rzeczywistego adaptera TLS i nadal nie jest wdrożona. Nadal nie ma poufnego transportu Companion, provisionowania kluczy, desktop executora ani OS-level sandboxa. W 0.6.32 usunięto okno TOCTOU w przejściach polityki timeoutów: sprawdzenie ważności i zapis aktywności korzystają z tej samej próbki zegara monotonicznego. Test regresyjny symuluje zegar, który zmienia wartość pomiędzy odczytami, i potwierdza, że deadline nie może zostać ukryty drugim odczytem. W 0.6.33 rozszerzono audyt odbiornika ramek: test współbieżnego replay potwierdza, że dwie równoległe próby tej samej ramki nie mogą obie przejść, a test własności klucza potwierdza, że odbiornik nie zależy od późniejszych zmian tablicy przekazanej przez wywołującego. Odbiornik jest jawnie opisany jako synchronizowany. W 0.6.35 usunięto możliwość przekazywania dowolnego parametru czasu do publicznych metod authority parowania: produkcyjna instancja sama odczytuje monotoniczny zegar, a seam testowy jest wewnętrzny. Aplikacja nie uruchamia obcego kodu; `PROJECT_TESTS` pozostaje `NOT_RUN`.

`ProjectWorkspaceStore` jest jedynym właścicielem prywatnego katalogu `filesDir/project_workspace`.

- `current/` — rozpakowane, odizolowane źródła projektu.
- `current.manifest` — wersjonowany manifest binarny: nazwa archiwum, czas importu, ścieżki, rozmiary i SHA-256.
- `snapshots/<id>/project/` — kopie poprzednich wersji workspace.
- `snapshots/<id>/manifest.bin` + `snapshot.meta` — manifest i czas wykonania kopii.
- `.staging-*` / `.previous-*` — katalogi transakcyjne; przy starcie/odczycie następuje próba naprawy przerwanego przełączenia.
- `ProjectCodeIndex` — deterministyczny indeks metadanych/ścieżek; nie przechowuje treści.
- `ProjectStructureAnalyzer` — ręczny, lokalny skaner symboli i importów Kotlin/Java z limitami odczytu.
- `readTextFile` — jedyna kontrolowana ścieżka odczytu tekstu: manifest, kanoniczna ścieżka, limit rozmiaru, SHA-256, UTF-8 i filtr sekretów.
- `ProjectPatchEngine` — ograniczony parser unified diff i generator podglądu wynikowej treści; waliduje bazowy SHA-256, ścisły kontekst hunków, ścieżki, duplikaty, limity i sekrety. Sam silnik nie zapisuje ani nie wykonuje zmian.
- `ProjectWorkspaceStore.applyPreview` — osobny, chroniony zapis zatwierdzonego preview: ponowna kontrola integralności, snapshot, staging, nowy manifest i transakcyjne przełączenie prywatnego workspace.
- Centrum dowodzenia udostępnia formularz preview diffu. Po walidacji 0.6.17.1 może uruchomić dwóch recenzentów na różnych darmowych profilach; 0.6.18 pozwala na zapis wyłącznie po ich pozytywnych werdyktach i dwóch jawnych potwierdzeniach użytkownika. Automatyczne generowanie unified diff bezpośrednio z odpowiedzi Mastera pozostaje przyszłym połączeniem.

Importer nie wykonuje plików, skryptów Gradle ani binariów. Nie zapisuje do katalogów instalacji ani repozytorium źródłowego aplikacji.

## Kontrakty, których kolejne etapy muszą przestrzegać

1. Każdy odczyt/zapis musi przechodzić przez `ProjectWorkspaceStore`; UI i agenci nie mogą budować ścieżek bezpośrednio.
2. Ścieżki względne są normalizowane i sprawdzane względem kanonicznego `current/`; żadnych ścieżek absolutnych ani `..`.
3. Manifest SHA-256 jest źródłem prawdy o wersji plików. Przed diffem i przed zastosowaniem patcha należy wykonać kontrolę integralności.
4. Import jest transakcyjny: staging → snapshot poprzedniego workspace → przełączenie katalogu. Nie wolno nadpisywać jedynej kopii.
5. Zmiany agentów muszą być propozycjami patchy, a nie bezpośrednim zapisem odpowiedzi modelu do pliku.
6. Sekrety, konfiguracje lokalne, klucze i katalogi środowiskowe są wyłączone z importu. Nie wolno przekazywać ich do kontekstu modelu.
7. Testy uruchamiane na kodzie użytkownika będą wymagały jawnego sandboxa/procesu z limitami czasu, pamięci i dostępu do sieci. Sam import nie uprawnia do uruchamiania Gradle.
8. Status `APPLIED` w ChangeSetStore nie może być nadawany wyłącznie na podstawie deklaracji agenta; musi odpowiadać rzeczywistemu zapisowi patcha i weryfikacji.

## Kolejność kolejnych wdrożeń

1. **Import + manifest + snapshot + integralność** — wdrożone w 0.6.13.
2. **Indeks metadanych i ograniczony podgląd plików** — wdrożone w 0.6.14. Indeks klasyfikuje ścieżki/rozszerzenia, a wybór kontekstowy dopasowuje nazwy/ścieżki; nie jest jeszcze indeksem AST ani symboli.
3. **Analiza strukturalna symboli i zależności** — wdrożona częściowo w 0.6.15 dla Kotlin/Java. Rozpoznaje podstawowe deklaracje i importy; nie jest pełnym AST ani analizą wywołań.
4. **Generator/podgląd patchy unified diff** — silnik walidacji i preview wdrożony w 0.6.16; bez zapisu.
5. **Peer Review patcha** — 0.6.17 dodaje lokalny audyt ryzyka i agregację werdyktów; 0.6.17.1 spina automatyczne wywołanie dwóch recenzentów przez `TeamRunEngine`, Smart Budget, checkpointy i dziennik wyników. Wymagane są dwa różne, zweryfikowane darmowe profile; brak płatnego fallbacku.
6. **Jawna zgoda użytkownika, snapshot i bezpieczny zapis** — wdrożone w 0.6.18; zapis tylko do prywatnego workspace, stan `APPLIED_UNVERIFIED`. 0.6.18.1 utwardza odzyskiwanie po przerwaniu operacji i czyści osierocone stagingi.
7. Lokalny runner weryfikacji integralności workspace/snapshotu i zgodności zakresu patcha — wdrożony w 0.6.19; loguje osobne wyniki PASS/FAIL/NOT_RUN.
8. Transakcyjne przywracanie zweryfikowanego snapshotu po wykryciu FAIL — wdrożone w 0.6.19.
9. Rzeczywisty executor kompilacji/testów projektu w odrębnym procesie z wymuszonymi limitami CPU/RAM/czasu/sieci — nadal wymagany; do jego wdrożenia nie uruchamiać skryptów Gradle, shell ani binariów z importowanego ZIP-a.
10. Bramka zaufania `ChangeSetStore`, migracja starych deklaracji i walidacja ścieżek — wdrożone w 0.6.19.1.
11. Kontrakt protokołu lokalnego executora — wdrożony w 0.6.20: modele bundle/request/receipt, SHA-256, zamknięta lista tasków, limity i podpisany dowód.
12. Generator zweryfikowanego ZIP bundle — wdrożony w 0.6.21: eksport wyłącznie zweryfikowanego snapshotu, manifest binarny, ponowna kontrola SHA-256 gotowego archiwum i zapis atomowy.
13. Skan treści i nazw plików przed eksportem — wdrożony w 0.6.22; heurystyki wykrywają popularne sekrety i blokują eksport przy wykryciu.
14. Kontrakt dwukierunkowego parowania companion — wdrożony w 0.6.23: nonce, TTL, HMAC-SHA256 po obu stronach, wiązanie klienta/sesji i jednorazowa weryfikacja; bez transportu i bez zapisywania sekretu.
15. Uwierzytelnione ramki companion — wdrożone w 0.6.24: HMAC-SHA256, osobne klucze kierunkowe, digest payloadu, wiązanie kierunku, ścisła sekwencja i ochrona przed replay; bez poufności i transportu.
16. Ograniczony binarny kodek ramek — wdrożony w 0.6.25: wersjonowanie, limity przed alokacją, ścisły UTF-8, allowlista typów/kierunków, kanoniczny Base64URL i odrzucanie trailing bytes.
17. Utwardzenie polityki cleartext — wdrożone w 0.6.26: domyślny zakaz HTTP, jawne wyjątki tylko dla localhost/127.0.0.1 i aliasu emulatora 10.0.2.2; klient odrzuca HTTP do LAN i z kluczem API oraz nie podąża automatycznie za przekierowaniami.
18. **Companion TLS/mTLS** — fundament platformowy 0.6.38 oraz rzeczywiste testy handshake na loopback 0.6.39; provisioning, pinning, rotacja, unieważnianie i integracja sesji nadal są kolejnymi bramkami.
19. Desktop Companion i rzeczywisty OS-level sandbox z wymuszonymi limitami; dopiero po audycie bezpieczne spięcie receipt z `PROJECT_TESTS` i rollbackiem.
20. Eksport Git / CI oraz fundament trwałej pamięci Mastera — etap 0.7.x.


## Aktualna kolejność po wydaniach 0.6.35–0.6.39

Poprzednie listy etapów Companion zostały zastąpione obowiązującym rejestrem „Rejestr kolejności i bramek” poniżej. Nie należy stosować starszych kolejności z wcześniejszych sekcji, jeśli różnią się od rejestru. Jedna cegiełka na wydanie; nie otwierać transferu przed ukończeniem bramek bezpieczeństwa.

## Ograniczenia 0.6.18–0.6.19.1
- Zapis odbywa się wyłącznie w prywatnym workspace aplikacji; nie modyfikuje oryginalnego archiwum ani repozytorium na komputerze użytkownika.
- 0.6.19 sprawdza integralność bieżącego workspace, snapshotu i dokładny zakres zmienionych ścieżek. To nie jest kompilacja ani testy semantyczne projektu.
- `PROJECT_TESTS` pozostaje `NOT_RUN`, ponieważ Android app nie ma jeszcze skonfigurowanego OS-level sandboxa z egzekwowanymi limitami CPU/RAM/czasu/sieci. Nie uruchamiamy nieufnych skryptów Gradle w procesie aplikacji.
- Status `APPLIED` wymaga `testStatus=PASS` oraz `testLevel=PROJECT_TESTS`; sam PASS integralności lub ręczny raport nie wystarczy.
- Przy wykryciu FAIL aplikacja próbuje odtworzyć zweryfikowany snapshot. Jeżeli sam snapshot jest uszkodzony lub zapis rollbacku się nie powiedzie, stan pozostaje jawnie nierozstrzygnięty i wymaga ręcznej interwencji.
- Jeśli aktualizacja rejestru zmian nie powiedzie się po zapisie, UI musi pokazać snapshotId i ostrzeżenie; użytkownik nie powinien ponawiać patcha bez kontroli stanu.

## Ograniczenia 0.6.17.1
- Automatyczna runda wymaga dwóch odrębnych, jawnie przypisanych i zweryfikowanych darmowych/lokalnych profili modelowych dla różnych ról agentów. Jeśli profil jest ten sam, recenzja nie startuje.
- Wynik recenzji pozostaje opinią modelu; nie jest dowodem poprawności i nie uprawnia do zapisu.

## Ograniczenia 0.6.17
- Analizator strukturalny obsługuje Kotlin/Java w ograniczonym zakresie i działa tylko ręcznie z Centrum.
- Nie ma pełnego AST, semantycznego rozwiązywania typów, analizy wywołań ani automatycznego przekazywania kodu agentom.
- Limity analizy: 300 plików, 64 KB na plik, 4 MB łącznie.

- Agenci nie mają jeszcze automatycznego dostępu do odczytu ani zapisu workspace; podgląd i analiza są lokalne oraz ręcznie inicjowane z Centrum.
- Analizator nie odtwarza pełnej semantyki języka ani grafu wywołań; rozpoznaje podstawowe deklaracje i zależności importów.
- 0.6.16 generuje wyłącznie podgląd wynikowej treści. Nie stosuje patchy, nie zapisuje plików, nie uruchamia testów projektu ani nie przywraca snapshotu z UI.
- Formularz patcha jest obecnie ręcznym wejściem kontrolnym. Automatyczne przekazywanie diffu z odpowiedzi Mastera/agentów zostanie spięte po wdrożeniu niezależnego Peer Review.
- Parser obsługuje ograniczony, jednoplikowy unified diff z nagłówkami `---` / `+++` i hunkami `@@`; nie obsługuje binarnych diffów, rename/copy, trybów plików ani rozszerzeń Git.
- Przed przyszłym zapisem wymagane będzie ponowne sprawdzenie integralności, SHA-256 i braku dowiązań symbolicznych/kolizji ścieżek; wynik preview nie jest autoryzacją zapisu.
- Kontrola SHA-256 wykrywa zmienione, brakujące, dodatkowe pliki i dowiązania symboliczne, ale sama niczego nie naprawia.


## 0.6.17 — stan Peer Review patcha
- `PatchPeerReviewEngine` analizuje zaakceptowany preview i wykrywa ryzykowne wzorce (m.in. sekrety, dynamiczne wykonywanie kodu, mostki JavaScript WebView, uprawnienia Androida, zmiany builda i usuwanie krytycznych plików).
- Dla dokładnego diffu tworzy ograniczony prompt recenzencki z SHA-256, ścieżką, operacją, wymaganiem dowodów i ścisłym formatem werdyktu.
- Agregator wymaga co najmniej dwóch różnych identyfikatorów recenzentów; sprzeczne werdykty pozostają konfliktem. Dwa APPROVE oznaczają wyłącznie gotowość do ludzkiej akceptacji, nigdy zgodę na zapis.
- Centrum dowodzenia pokazuje wstępny audyt i umożliwia skopiowanie promptu niezależnej recenzji.
- W stanie 0.6.17 automatyczne wywołanie API nie było jeszcze zintegrowane; zostało dodane w 0.6.17.1. Wyniki są logowane w dziennikach i checkpointach aplikacji.

- **Pamięć Mastera:** w 0.6.17 dodano specyfikację `docs/MASTER_MEMORY_ARCHITECTURE_PL.md` i zinwentaryzowano istniejące magazyny; wdrożenie wspólnego modelu pamięci pozostaje planowane na 0.7.0.


## 0.6.17.1 — automatyczny patch review
- Centrum dowodzenia przekazuje dokładny prompt/diff do dwóch agentów przez istniejący `TeamRunEngine`.
- Recenzenci muszą mieć różne fingerprinty przypisanych profili modelowych i zweryfikowany darmowy/lokalny status.
- Smart Budget wymaga pełnej rezerwacji dla dwóch recenzji; brak budżetu blokuje rundę w całości.
- Wyniki i checkpointy są zapisywane w istniejących dziennikach aplikacji.
- Agregator nie ukrywa negatywnego werdyktu lub BLOCKER tylko dlatego, że brakuje drugiej odpowiedzi.
- W 0.6.17.1 zapis nie był jeszcze dostępny; został dodany w 0.6.18 z obowiązkowym snapshotem i zgodą użytkownika.


## 0.6.18 — zatwierdzanie i zapis workspace
- Po dwóch pozytywnych recenzjach użytkownik wykonuje osobne, jawne zatwierdzenie i potwierdzenie operacji.
- `ProjectWorkspaceStore.applyPreview` ponownie sprawdza integralność i SHA-256, tworzy snapshot, stosuje patch w stagingu, przebudowuje manifest i przełącza katalog transakcyjnie.
- Operacje ADD/MODIFY/DELETE są ograniczone do dozwolonych plików tekstowych; sekrety, chronione ścieżki, NUL, błędne UTF-8, kolizje nazw i nieaktualny base hash blokują zapis.
- `ChangeSetStore` przechowuje snapshotId i status `APPLIED_UNVERIFIED`. Status `APPLIED` wymaga późniejszego PASS testów.
- Wykryto i naprawiono zdublowaną deklarację `symlink` w `ProjectWorkspaceStore`, która uniemożliwiała kompilację Kotlin.


## 0.6.18.1 — crash recovery hardening
- Po poprawnym odzyskaniu `current/` + `current.manifest` usuwane są osierocone `.staging-*` oraz `.patch-staging-*` i ich manifesty.
- Jeżeli aktywna para jest niekompletna, najpierw przywracany jest ostatni dostępny `.previous-*`; sprzątanie stagingu nie może wyprzedzać odzyskiwania.
- Testy regresyjne odzyskiwania i sprzątania stagingu dodane do `ProjectWorkspaceStoreApplyTest`.
- Lokalna kompilacja komponentów Kotlin/JVM PASS; testy trzech klas: 33/33 PASS; pełny Gradle/APK NOT RUN.


## 0.6.19 — workspace verification + rollback
- `ProjectWorkspaceStore.verifySnapshot()` sprawdza manifest, SHA-256, brakujące/zmienione/nadmiarowe pliki i symlinki snapshotu.
- `restoreSnapshot()` najpierw weryfikuje snapshot, kopiuje go do stagingu, ponownie sprawdza kopię i wykonuje transakcyjne przełączenie. Zdrowy bieżący workspace otrzymuje dodatkowy snapshot bezpieczeństwa; uszkodzony workspace nie jest bezrefleksyjnie kopiowany jako zdrowy backup.
- `ProjectTestRunner` porównuje bieżący manifest z snapshotem i sprawdza, czy rzeczywisty zakres zmian zgadza się z ChangeSet. Raportuje osobno `WORKSPACE_INTEGRITY`, `SNAPSHOT_INTEGRITY`, `PATCH_SCOPE` i `PROJECT_TESTS`.
- Gdy integralność lub zakres patcha nie przejdzie kontroli, UI uruchamia rollback do zweryfikowanego snapshotu i aktualizuje rejestr na `ROLLED_BACK`, jeśli przywrócenie się powiedzie.
- `ChangeSetStore` zapisuje poziom weryfikacji. `APPLIED` wymaga `PASS` na poziomie `PROJECT_TESTS`; `WORKSPACE_INTEGRITY` nie może awansować zmiany do `APPLIED`.
- Ograniczenie świadome: brak rzeczywistego sandboxa procesu na Androidzie oznacza, że kodu użytkownika nie wykonujemy. Wszystkie kontrole metadanych mogą przejść, ale wynik całości pozostaje `NOT_RUN`, dopóki testy projektu nie zostaną wykonane przez izolowany executor.


## 0.6.19.1 — execution trust gate hardening
- Zamknięto możliwość zapisania ręcznego `PASS / PROJECT_TESTS` przez publiczne API `ChangeSetStore`.
- Wyniki lokalnych kontroli zapisuje wyłącznie `recordWorkspaceVerification()`; raporty ręczne i zgodności wstecznej mają poziom `LEGACY_UNVERIFIED`.
- Historyczne wpisy `PROJECT_TESTS` z wersji bez executora są degradowane do `NOT_RUN / LEGACY_UNVERIFIED`.
- Po statusie `APPLIED` nie można podmienić dowodu ani snapshotu.
- Runner odrzuca niebezpieczne/powielone ścieżki oraz raportuje wyjątki porównania zakresu jako `FAIL`.
- Następny krok: kontrakt lokalnego executora desktopowego; nie uruchamiać obcego kodu w procesie aplikacji Android.


## 0.6.34 — kanoniczny Base64URL w granicy odbiornika
- Audyt wykazał, że `CompanionFrameWireCodec` odrzucał niekanoniczne Base64URL, ale publiczne `Receiver.verify()` mogło zaakceptować alternatywną reprezentację tych samych bajtów, gdy wywołujący omijał kodek.
- Odbiornik po dekodowaniu ponownie koduje payload bez paddingu i wymaga identyczności z wejściowym tekstem; alternatywna reprezentacja zwraca `NON_CANONICAL_BASE64` bez zużycia numeru sekwencyjnego.
- Test regresyjny używa pary `AA` / `AB`, które dekoder Java może zinterpretować jako ten sam bajt, i potwierdza, że poprawna ramka nadal może zostać zaakceptowana po odrzuceniu niekanonicznej.
- Ukierunkowany zestaw Companion: 34/34 PASS. Nadal nie ma transportu TLS/mTLS, desktop Companion ani OS-level sandboxa.

## 0.6.33 — współbieżność i własność klucza odbiornika Companion
- Potwierdzono testem, że równoległe dostarczenie tej samej ramki do jednego odbiornika kończy się dokładnie jednym `ACCEPTED`; druga próba otrzymuje `SEQUENCE_MISMATCH`.
- Potwierdzono testem, że odbiornik przechowuje niezależną kopię klucza sesji: wyzerowanie tablicy klucza po konstrukcji nie wpływa na poprawną weryfikację ramki.
- Doprecyzowano w dokumentacji kodu, że odbiornik jest synchronizowany i serializuje weryfikację sekwencji.
- Ukierunkowany zestaw Companion: 33/33 PASS. Nie dodano transportu ani nowej granicy zaufania.

## 0.6.32 — spójność próbkowania zegara timeoutów Companion
- Wszystkie przejścia polityki timeoutów pobierają jedną próbkę `nanoTime`.
- Ta sama wartość służy do sprawdzenia deadline i aktualizacji znacznika czasu, eliminując rozjazd między kontrolą a zapisem.
- Dodano test regresyjny z zegarem zmieniającym wartość pomiędzy odczytami.
- Ukierunkowany zestaw Companion: 31/31 PASS; pełny Gradle/Robolectric i urządzenie pozostają NOT RUN.

## 0.6.31 — polityka timeoutów sesji Companion
- Dodano `CompanionSessionTimeoutPolicy` z osobnymi limitami handshake, bezczynności, transferu i hard lifetime.
- Zegar domyślny to `System.nanoTime`; porównanie przez różnicę czasu obsługuje zawijanie licznika monotonicznego dla rozsądnych limitów krótszych niż 2^63 ns.
- `recordAuthenticatedActivity()` odświeża idle timeout, ale nigdy nie przesuwa początku sesji ani twardego deadline.
- Transfer ma jeden aktywny slot i własny limit; nie można rozpocząć transferu przed zakończeniem fazy handshake ani zakończyć go dwukrotnie.
- To wyłącznie polityka czasu. `markHandshakeFinished()` nie jest dowodem uwierzytelnienia; caller ma obowiązek wywołać metody aktywności dopiero po zweryfikowaniu ramek. Klasa nie otwiera socketów, nie weryfikuje TLS i nie kończy samodzielnie sesji/odbiornika.

## 0.6.30 — terminalność odbiornika ramek Companion
- `CompanionFrameProtocol.Receiver` po poprawnie uwierzytelnionej ramce `CLOSE` przechodzi w stan terminalny; wszystkie kolejne ramki są odrzucane jako `SESSION_CLOSED`.
- Dodano jawne `close()` dla unieważnienia przy timeout/błędzie transportu i best-effort zerowanie kopii klucza. Uwierzytelnione wyczerpanie `Long.MAX_VALUE` zamyka odbiornik. Niepoprawny MAC `CLOSE` nie zamyka sesji.
- Nie jest to pełna maszyna stanów ani TLS: nie ma adaptera zdolnego bezpiecznie wystawić tożsamość TLS peer. Nie przyjmujemy samego boolean `accepted` jako dowodu uwierzytelnienia.
- Testy regresyjne weryfikują terminalność, unieważnienie, wyczerpanie sekwencji i odporność na nieautoryzowany CLOSE.

## 0.6.23 — kontrakt parowania companion
- `CompanionPairingAuthority` tworzy krótkotrwałe challenge z losowym nonce 256-bit i identyfikatorem sesji; HMAC wyzwania uwierzytelnia Android przed companionem.
- Dowód companion to HMAC-SHA256 obejmujący wersję protokołu, sesję, klienta, companion, nonce, expiry i HMAC wyzwania. Obie strony uwierzytelniają się wspólnym PSK; weryfikacja jest jednorazowa i odporna na ponowne użycie challenge.
- Sekret 16–64 bajty jest dostarczany poza kanałem transportowym; aplikacja nie zapisuje go ani nie loguje. Nie wdrożono jeszcze bezpiecznego provisionowania.
- 0.6.23 utwardza także skan sekretów (UTF-16 / bounded read) i weryfikację manifestu ZIP (bounded read).
- To nie jest jeszcze transport, szyfrowanie kanału, ECDH, companion desktopowy ani sandbox. `PROJECT_TESTS` pozostaje `NOT_RUN`.


## 0.6.24 — uwierzytelnione ramki companion
- `CompanionFrameProtocol` definiuje zamkniętą listę typów wiadomości: `PAIR_CONFIRM`, `BUNDLE_CHUNK`, `BUNDLE_COMPLETE`, `EXECUTION_RECEIPT`, `PING`, `CLOSE`; nie ma typu dowolnego polecenia shell.
- Dwa odrębne klucze sesji są wyprowadzane przez HMAC-SHA256 z PSK i kontekstu sesji/klienta/companion/nonce/kierunku, z separacją domeny od HMAC parowania; uniemożliwia to odbicie ramki w przeciwnym kierunku. Wywołujący musi najpierw uzyskać pozytywny wynik `CompanionPairingAuthority.verify`.
- Każda ramka wiąże wersję, identyfikator sesji, kierunek, numer sekwencyjny, typ, rozmiar i SHA-256 payloadu w MAC. Odbiorca wymaga dokładnie następnego numeru, odrzuca replay, zmianę treści, błędny Base64 i payload większy niż 1 MiB.
- Ramki zapewniają uwierzytelnienie i integralność, ale NIE poufność. Nie wolno przesyłać nimi sekretów ani traktować ich jako gotowego bezpiecznego transportu sieciowego. TLS lub równoważna, zweryfikowana warstwa szyfrująca oraz bezpieczne provisionowanie klucza pozostają wymagane przed transferem przez sieć.
- Nie dodano socketów, discovery, desktop executora ani OS sandboxa. Kod importowanego projektu nadal nie jest uruchamiany; `PROJECT_TESTS` pozostaje `NOT_RUN`.


## 0.6.25 — ograniczony kodek ramek companion
- `CompanionFrameWireCodec` serializuje ramki do wersjonowanego formatu binarnego `AIMF`; nie otwiera połączeń i nie wykonuje operacji systemowych.
- Parser odrzuca wejście większe niż 1 400 000 bajtów przed parsowaniem, ogranicza długości pól przed alokacją, wymaga poprawnego UTF-8, znanych enumów, poprawnych metadanych i braku dodatkowych bajtów.
- Payload Base64URL musi mieć oczekiwaną długość i kanoniczne kodowanie bez paddingu; niekanoniczne aliasy są odrzucane.
- Kodek nie potwierdza autentyczności: każda zdekodowana ramka nadal musi przejść `CompanionFrameProtocol.Receiver.verify()`.
- Nadal brak poufności, TLS, bezpiecznego provisionowania, transportu sieciowego, desktop executora i OS sandboxa. `PROJECT_TESTS` pozostaje `NOT_RUN`.


## 0.6.26 — utwardzenie polityki cleartext
- Manifest Androida ustawia `usesCleartextTraffic=false` i wskazuje `network_security_config.xml`; domyślna polityka blokuje HTTP.
- Jawne wyjątki sieciowe są ograniczone do `localhost`, `127.0.0.1` i `10.0.2.2` (alias hosta emulatora). Lista w `CleartextEndpointPolicy` jest utrzymywana zgodnie z konfiguracją XML.
- `ProviderClient` odrzuca cleartext do adresów LAN, z kluczem API oraz z danymi uwierzytelniającymi w query; automatyczne podążanie za przekierowaniami jest wyłączone, aby nie dopuścić do niejawnego downgrade/forwardingu nagłówków.
- To celowo wyłącza dotychczasowe niezabezpieczone endpointy Ollama pod adresami LAN; do takiego użycia potrzebny będzie HTTPS z walidacją certyfikatu. Alias emulatora `10.0.2.2` pozostaje dozwolony dla lokalnego testowego Ollama.
- Nie jest to jeszcze TLS/mTLS companion ani cert pinning.


## 0.6.27 — ograniczone odpowiedzi dostawców

- Zastąpiono nieograniczony odczyt `readText()` strumieniowym odczytem o limicie 4 MiB.
- Zbyt duże odpowiedzi kończą się `RESPONSE_TOO_LARGE`; niepoprawne UTF-8 kończy się `INVALID_RESPONSE_ENCODING`.
- Testy graniczne readera: 4/4 PASS; pełny Gradle i APK pozostają NOT RUN.
- Następny bezpieczny krok: audyt i projekt TLS/mTLS dla companion, bez przesyłania poufnych danych przez HMAC-only transport.


## 0.6.28 — walidacja endpointów i projekt bezpieczeństwa Companion

- Dodano `ProviderEndpointPolicy`: adres jest parsowany jako URI/URL przed otwarciem połączenia; akceptowane są wyłącznie HTTP i HTTPS.
- Odrzucane są nieobsługiwane schematy (np. `file:`/`ftp:`), błędne adresy, brak hosta, port 0 i porty powyżej 65535 oraz user-info w URL.
- Reguła cleartext pozostaje fail-closed: tylko `localhost`, `127.0.0.1`, `10.0.2.2`, bez API key i bez danych uwierzytelniających w query (również po percent-decoding). Porównanie hostów jest niezależne od ustawień locale.
- Dodano testy polityki endpointów i dokument architektury TLS/mTLS, provisionowania, transferu bundle i bramek sandboxa.
- Audyt potwierdza, że obecne HMAC Companion nie zapewnia poufności; nie dodano socketów ani TLS. `PROJECT_TESTS` nadal `NOT_RUN`.
- Kotlin/JVM harness polityki endpointów z `-Werror`: 18/18 PASS. Zestaw regresyjny Kotlin/JVM z `-Werror`: 29/29 PASS (pairing, ramki, kodek, executor, cleartext i endpoint policy); reader odpowiedzi dostawcy: 4/4 PASS. XML manifestu i network security config: PASS (parsowanie). Pełny Gradle, testy Android/Robolectric, APK i urządzenie: NOT RUN.


## 0.6.29 — pairing DoS hardening i lifecycle Companion
- `CompanionPairingAuthority.verify()` nie usuwa oczekującego challenge przed sprawdzeniem MAC. Błędny sekret lub zmieniony challenge authenticator nie blokują już prawidłowej próby; challenge jest zużywany wyłącznie po poprawnym proof.
- Porównanie `challengeAuthenticator` wykorzystuje `MessageDigest.isEqual`, tak samo jak MAC proof.
- Dodano regresje na próbę zużycia challenge przez błędny sekret i przez zmieniony authenticator.
- Rozszerzono dokument projektowy o jawne stany sesji, terminalność CLOSE/FAILED, timeouty, bramki tożsamości TLS, reguły transferu i rozdzielenie `TRANSFER_VERIFIED` od uruchomienia kodu.
- Nie wdrożono transportu, TLS, desktop Companion ani sandboxa.

## Rejestr kolejności i bramek — utrzymywać bez przestawiania

**Zasada pracy:** jedna mała, testowalna cegiełka na wydanie; najpierw audyt, potem zmiana, regresje, kontrola dokumentacji i archiwum. Nie budować transportu ani executora na niezweryfikowanym kontrakcie. Każdy status ma rozróżniać PASS / FAIL / NOT RUN / NOT IMPLEMENTED.

### Ścieżka Companion — kolejność obowiązująca
1. [x] Własność zegara TTL parowania — 0.6.35.
2. [x] Niepodrabialny na poziomie API, jednorazowy receipt wydawany przez authority; `accepted` jest diagnostyczne, a receipt jest sprawdzany przez tożsamość obiektu i można go odebrać tylko raz — 0.6.36. To nie jest granica bezpieczeństwa dla złośliwego kodu w tym samym procesie.
3. [x] `CompanionSessionOwner`: jawne stany `NEW`, `PAIRED`, `ACTIVE`, `TRANSFERRING`, `CLOSED`, `FAILED`; konsumuje receipt z przypisanej authority, wyprowadza klucz odbiorczy, zarządza receiverem i timeoutami, a timeout/close prowadzi do stanu terminalnego — 0.6.37. Właściciel sam tworzy politykę timeoutów; zegar testowy jest dostępny wyłącznie przez konstruktor wewnętrzny. `ACTIVE` oznacza zakończone parowanie PSK, nie weryfikację TLS/mTLS.
4. [~] TLS/mTLS: 0.6.38 dodaje platformowy SSLContext; 0.6.39 potwierdza handshake TLS/mTLS na loopback; zrekonstruowane 0.6.40 dodaje SPKI pinning po PKIX; 0.6.41 wiąże jednorazowy dowód TLS peer z konkretnym profilem, mapą peer ID → SPKI i `CompanionSessionOwner`. Nadal brak trwałego provisioningu, rotacji/unieważniania i testów na Androidzie.
5. [~] Provisionowanie i trwałe mapowanie peer ID → SPKI: 0.6.42 dodaje klucz EC P-256 w Android Keystore, nieeksportowalne podpisywanie challenge, AES-256-GCM dla mapy pinów, current/next, jawne promote/cancel i revocation. 0.6.43 dodaje domenowo separowany challenge proof oraz preferowaną ścieżkę tworzenia profilu TLS i `CompanionSessionOwner` bezpośrednio z aktualnej mapy zaufania. 0.6.44 dodaje walidację aktualnego zaufania peer przy aktywacji i przed każdą kolejną operacją sesji; rotacja promote/unieważnienie powoduje fail-closed sesji przy następnym użyciu. Nadal brakuje certyfikatu TLS z SAN wydanego/provisionowanego przez zaufany proces, migracji PSK, odzyskiwania/ponownego parowania, natychmiastowego zamknięcia gniazda TLS (właściciel sesji nie zarządza jeszcze socketem) i testów Android/Keystore na urządzeniu.
6. [ ] Transport Companion: ograniczony transfer bundle, staging, manifest/digest, przerwania, timeouty, replay i reconnect; bez wykonywania w trakcie odbioru.
7. [ ] Desktop Companion i integracyjne testy obu stron.
8. [ ] OS-level sandbox w odrębnym procesie z egzekwowanymi limitami CPU/RAM/czasu/sieci/pliku; dopiero potem realne `PROJECT_TESTS`.

### Ścieżka aplikacji — równolegle, ale bez omijania bramek
9. [ ] Pełny Gradle/Robolectric i diagnoza wszystkich błędów buildu.
10. [ ] Zweryfikowany APK, instalacja/aktualizacja i test na urządzeniu.
11. [ ] Trwała pamięć Mastera: rozdzielenie historii, wiedzy, logów, checkpointów i danych uczących się; retencja, eksport i kontrola użytkownika.
12. [ ] Efektywność agentów: routing, ocena jakości, redukcja niepotrzebnych wywołań i rzeczywiste rozliczanie tokenów.
13. [ ] Automatyzacja patchy i Git/CI: propozycje, review, jawna zgoda, test, rollback i powtarzalne wydania.

**Bieżący punkt:** pozycje 1–3 ukończone. Fundament TLS/mTLS, handshake loopback, SPKI pinning i integracja dowodu peer z `CompanionSessionOwner` są zaimplementowane w 0.6.38–0.6.41. Pozycja 5 obejmuje trwały provisioning (0.6.42), proof-of-possession i ścieżkę budowy profilu/owner (0.6.43) oraz ponowną walidację zaufania przy aktywacji i każdej operacji sesji (0.6.44). Rotacja promote/unieważnienie jest wykrywana przez ownera i kończy sesję stanem `FAILED` przy następnym użyciu; nie oznacza to jeszcze natychmiastowego zamknięcia socketu TLS, ponieważ owner nie zarządza obecnie socketem. Pozycja 5 pozostaje częściowa: brak certyfikatu TLS z poprawnym SAN i procesu jego wydania, migracji PSK, recovery/re-pairing i testów Android/Keystore na urządzeniu. Nie otwierać transportu ani transferu bundle przed zamknięciem tych bramek.


## 0.6.38 — platformowy fundament TLS/mTLS (częściowy punkt 4)
- Dodano `CompanionTlsContext` oparty na platformowych `KeyManagerFactory`, `TrustManagerFactory` i `SSLContext`; brak własnego TLS i brak trust-all.
- Wymagany jest wpis klucza prywatnego z łańcuchem certyfikatów oraz jawny, niepusty trust store.
- Klient tworzy socket przez TLS socket factory dla konkretnego hosta i ustawia `HTTPS` endpoint identification przed handshake. Serwer wymaga certyfikatu klienta przez `needClientAuth=true`.
- Dozwolone wyłącznie TLS 1.2/1.3; brak TLS 1.2 oznacza fail-closed.
- Testy Kotlin/JVM `-Werror`: 55/55 PASS, 10 powtórzeń: 550/550 PASS.
- To tylko fundament konfiguracji. Brak certyfikatów, provisioning, SPKI pinning, rotacji/unieważniania, pełnego handshake, transportu i integracji z właścicielem sesji. Pozycja 4 pozostaje w toku; transfer bundle nadal zabroniony.


## 0.6.39 — rzeczywiste testy handshake TLS/mTLS (częściowy punkt 4)
- Dodano wyłącznie testowe certyfikaty CA/serwera/klienta i klucze fixture w `app/src/test/resources/companion-tls/`; nie są przeznaczone do produkcji.
- Potwierdzono pozytywny handshake mTLS z zaufanymi certyfikatami oraz osobny handshake TLS 1.2.
- Testy negatywne: brak certyfikatu klienta, klient z niezaufanym łańcuchem, błędny SAN serwera i serwer z niezaufanym łańcuchem.
- Kotlin/JVM `-Werror`: 61/61 PASS; 10 powtórzeń: 610/610 PASS.
- To nie jest provisioning ani transport produkcyjny. Brak pinningu, rotacji/unieważniania, integracji z `CompanionSessionOwner`, testu na Androidzie, Desktop Companion i sandboxa. `PROJECT_TESTS` pozostaje `NOT RUN`.


## 0.6.40 — SPKI pinning po walidacji PKIX (rekonstrukcja)
- Odtworzono zmianę SPKI pinning na bazie odzyskanych źródeł 0.6.39; oryginalne archiwum 0.6.40 nie udostępniało bajtów.
- Certyfikat peer musi przejść platformową walidację PKIX, a następnie dopasować się do jawnego SHA-256 DER SubjectPublicKeyInfo. Obsługiwany jest zestaw current+next, ale nie mechanizm rotacji.
- Wybrane testy Kotlin/JVM: 15/15 PASS, 7 powtórzeń: 105/105 PASS; nie jest to pełny Gradle/Robolectric.

## 0.6.41 — tożsamość TLS peer związana z CompanionSessionOwner
- `CompanionPinnedTlsProfile` sam tworzy i zachowuje prywatny SSLContext; tylko sockety utworzone/zaakceptowane przez ten profil mogą wygenerować receipt.
- Receipt jest obiektem jednorazowym i wiąże pairing session ID, peer ID, rolę lokalną, SPKI oraz konkretną sesję TLS. Mapa pinów jest przypisana do konkretnego peer ID.
- `CompanionSessionOwner` otrzymuje profil TLS w konstruktorze. Aktywacja bez TLS receipt jest blokowana; obcy profil, obcy receipt i replay są odrzucane.
- Połączenie klienta ma jawny timeout TCP; profil ogranicza liczbę gniazd serwera i nieodebranych receiptów.
- Testy Kotlin/JVM `-Werror`: 29/29 PASS, 5 powtórzeń: 145/145 PASS; rzeczywisty handshake mTLS loopback w testach. Gradle/Robolectric i urządzenie Android: NOT RUN.
- Nadal brak Android Keystore provisioning, rotacji/unieważniania, transportu Companion, Desktop Companion i OS sandboxa. `PROJECT_TESTS` pozostaje `NOT RUN`.


## 0.6.42 — Android Keystore i trwała mapa zaufania Companion (częściowy punkt 5)
- Dodano `CompanionProvisioningStore`: generuje lokalną tożsamość EC P-256 w Android Keystore i udostępnia podpisywanie challenge bez eksportu klucza prywatnego.
- Mapa peer ID → current/next SPKI jest serializowana do app-private preferences i chroniona AES-256-GCM kluczem Android Keystore oraz AAD. Zapis używa synchronicznego `commit()` i zgłasza błąd, jeśli nie został utrwalony.
- Utrata klucza szyfrującego przy istniejących danych kończy się fail-closed i wymaga jawnego odzyskiwania; nie ma cichego wygenerowania nowego klucza i pozornej utraty/zmiany zaufania.
- Rotacja: stage next, promote next, cancel staged; nie można po cichu zastąpić już oczekującego pinu. Revocation usuwa bieżący i oczekujący pin.
- Dodano czyste testy polityki current/next: 5/5 PASS. Wcześniejszy zestaw TLS/owner 29/29 PASS oraz owner 14/14 PASS.
- Ograniczenie: wygenerowany certyfikat Keystore jest lokalnym identyfikatorem klucza, nie certyfikatem TLS z SAN. Nie podłączono jeszcze tego materiału do `CompanionPinnedTlsProfile`/`CompanionSessionOwner`; wymagany jest bezpieczny proces wydania certyfikatu z właściwym SAN i zaufanym łańcuchem. Migracja PSK, recovery/re-pairing i testy na Androidzie pozostają otwarte.
- Próba `./gradlew :app:compileDebugKotlin --no-daemon` zablokowana przed kompilacją: `UnknownHostException: services.gradle.org`; pełny Gradle/Robolectric, APK i urządzenie Android: NOT RUN (brak dostępnego Android SDK i lokalnej dystrybucji Gradle). `PROJECT_TESTS`: NOT RUN.


## 0.6.43 — integracja mapy zaufania z profilem TLS i proof-of-possession (częściowy punkt 5)
- `CompanionIdentityChallenge` wprowadza domenowo separowany komunikat podpisywany przez klucz EC. Weryfikacja używa publicznego klucza certyfikatu i odrzuca pusty/przekraczający limit challenge oraz niepoprawny/podejrzanie duży podpis.
- `CompanionProvisioningStore.signChallenge()` podpisuje teraz wyłącznie domenowo separowany komunikat; podpisów z innych protokołów nie można bezpośrednio użyć jako dowodu Companion.
- `createPinnedTlsProfile()` pobiera aktualną, odszyfrowaną mapę peer ID → current/next SPKI i buduje profil TLS. Pusta mapa blokuje utworzenie profilu.
- `createSessionOwner()` jest preferowaną ścieżką tworzenia: wiąże świeży profil zaufania z nowym `CompanionSessionOwner`, zamiast polegać na ręcznym przekazywaniu potencjalnie nieaktualnej mapy pinów.
- Profile są snapshotami: po rotacji/unieważnieniu należy zamknąć stare profile/sesje i utworzyć nowe. Automatyczne odcinanie już aktywnych połączeń nie jest jeszcze zaimplementowane.
- Test kryptograficzny JVM: 5/5 przypadków PASS. Nowy kod provisioning + profil TLS + owner przeszedł `kotlinc -Werror` z atrapami API Android/JSON; to kontrola składni i typów, nie test Android Keystore.
- Pełny Gradle/Robolectric, test Android Keystore, APK i test urządzeniowy: NOT RUN; środowisko nadal nie ma dostępnej dystrybucji Gradle/Android SDK. `PROJECT_TESTS`: NOT RUN.
- Nadal brakuje certyfikatu TLS z zaufanym łańcuchem i SAN, migracji PSK, recovery/re-pairing i unieważnienia aktywnych sesji. Transport pozostaje zablokowany.


## 0.6.44 — egzekwowanie aktualnego zaufania peer przez właściciela sesji (częściowy punkt 5)
- `CompanionSessionOwner` otrzymuje walidator zaufania peer; preferowana ścieżka `CompanionProvisioningStore.createSessionOwner()` wiąże go z aktualnym, odszyfrowanym magazynem pinów.
- Aktywacja odrzuca receipt, jeżeli pin peer został już unieważniony lub nie jest już akceptowany (`PEER_REVOKED`).
- Przed `verifyIncoming`, `beginTransfer`, `finishTransferAfterValidation` i `pollTimeout` owner ponownie sprawdza, czy dokładny peer ID + SPKI nadal występuje jako current/next. Brak rekordu, błąd odczytu/uwierzytelnienia magazynu lub wyjątek walidatora oznacza fail-closed i stan `FAILED`.
- Promocja rotacji, która usuwa stary pin, jest wykrywana przy następnej operacji sesji. Etapowanie next nie odcina aktualnego current.
- Dodano dwa testy: unieważniony peer nie aktywuje sesji na bazie wcześniej wydanego TLS receipt; aktywna sesja przechodzi do `FAILED` przy następnym użyciu po unieważnieniu.
- TLS/Owner: 31/31 PASS; 5 powtórzeń: 155/155 PASS. Kompilacja wybranych klas core + provisioning store przez `kotlinc -Werror` z atrapami Android/JSON: PASS.
- Ograniczenie: owner nie posiada jeszcze i nie zamyka socketu TLS, więc wykrycie revocation następuje przy następnym wywołaniu API sesji, a nie natychmiast w chwili zmiany magazynu. Transport nadal nie istnieje i pozostaje zablokowany.
- Pełny Gradle/Robolectric, prawdziwy Android Keystore, APK i test urządzeniowy: NOT RUN. `PROJECT_TESTS`: NOT RUN.
